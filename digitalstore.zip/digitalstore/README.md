# DIGITAL STORE — Telegram Order Bot

Bot Telegram untuk mengurus tempahan item digital secara automatik.
Dibina menggunakan **aiogram 3** (async) dan **SQLite**.

─────────────────────────────────────────────

## STRUKTUR PROJEK

```
digitalstore/
│
├── main.py              ← Entry point — jalankan fail ini
├── config.py            ← Tetapan: BOT_TOKEN, ADMIN_ID, QR Code
├── database.py          ← Semua operasi SQLite (items & orders)
├── requirements.txt      ← Senarai pakej yang diperlukan
├── .env.example          ← Contoh fail environment variable
│
├── handlers/
│   ├── __init__.py
│   ├── user.py          ← /start, klik item, hantar bukti bayaran
│   └── admin.py         ← /add, /success, /send
│
├── utils/
│   ├── __init__.py
│   ├── texts.py         ← Semua templat mesej (aesthetic)
│   ├── keyboards.py     ← Pembina inline keyboard
│   └── states.py        ← FSM states untuk /add
│
├── assets/
│   └── qrcode.png        ← Letakkan QR Code anda di sini
│
└── store.db              ← Database (dicipta automatik)
```

─────────────────────────────────────────────

## PEMASANGAN (INSTALLATION)

### 1. Pastikan Python 3.10+ dipasang

```bash
python --version
```

### 2. Pasang dependency

```bash
cd digitalstore
pip install -r requirements.txt
```

─────────────────────────────────────────────

## KONFIGURASI

Semua tetapan berada dalam fail **`config.py`**.

### A. BOT_TOKEN

1. Buka Telegram, cari **@BotFather**.
2. Hantar `/newbot` dan ikut arahan untuk dapatkan token.
3. Buka `config.py`, ganti:

```python
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "PASTE_BOT_TOKEN_DISINI")
```

   dengan token sebenar:

```python
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "123456789:AAExampleToken")
```

   **ATAU** set environment variable (lebih selamat):

```bash
export BOT_TOKEN="123456789:AAExampleToken"
```

### B. ADMIN_ID

User ID Telegram admin sudah ditetapkan dalam `config.py`:

```python
ADMIN_IDS: list[int] = [
    7624612389,
]
```

Boleh tambah lebih dari satu admin dengan menambah ID baru
dalam senarai (dipisahkan dengan koma).

> Untuk dapatkan User ID, hantar `/start` kepada **@userinfobot**.

### C. QR CODE PEMBAYARAN

Bot menyokong **2 cara** menghantar QR Code, dengan logik
automatik (fail PNG dahulu → jika gagal, beralih ke link):

**Pilihan 1 — Fail PNG (disertakan dalam zip)**

Letakkan fail QR Code anda di:

```
assets/qrcode.png
```

Bot akan cuba menghantar fail ini dahulu.

**Pilihan 2 — Link (fallback automatik)**

Dalam `config.py`, set:

```python
QR_CODE_URL: str = "https://link-ke-qrcode-anda.png"
```

Jika `assets/qrcode.png` **tidak wujud** atau **gagal dihantar**
(contoh: fail rosak/corrupt), bot akan **automatik** menghantar
QR Code melalui `QR_CODE_URL` sebagai gantinya. Pembeli tidak
akan tertinggal QR Code dalam apa jua keadaan.

─────────────────────────────────────────────

## CARA JALANKAN BOT

```bash
python main.py
```

Jika berjaya, anda akan lihat log seperti:

```
2026-06-13 12:00:00 | INFO | __main__ | Bot sedang dimulakan...
```

Bot kini sedia menerima `/start` dari pengguna.

─────────────────────────────────────────────

## CARA PENGGUNAAN

### Untuk Admin

**1. Tambah Item**

```
/add Panel Unlimited
```

Bot akan balas meminta harga. Balas dengan nombor:

```
25
```

Item terus muncul sebagai butang di menu `/start`.

**2. Sahkan Pembayaran**

Selepas pembeli hantar bukti pembayaran, admin akan
menerima notifikasi. Untuk sahkan:

```
/success 123456789
```

(gantikan `123456789` dengan User ID pembeli)

**3. Hantar Produk**

1. Hantar media/teks yang ingin dihantar kepada pembeli
   (boleh hantar dalam private chat dengan bot anda sendiri,
   atau di mana-mana chat yang bot ada akses).
2. **Reply** mesej tersebut dengan:

```
/send 123456789
```

Bot akan menyalin kandungan tersebut dan menghantarnya
kepada pembeli. Disokong: text, photo, video, audio,
document, sticker, dan semua jenis media Telegram.

### Untuk Pembeli

1. Taip `/start`.
2. Pilih item dari senarai butang.
3. Bayar mengikut QR Code yang dihantar.
4. Hantar bukti pembayaran (gambar/dokumen/fail).
5. Tunggu pengesahan daripada admin.
6. Produk akan dihantar oleh admin selepas disahkan.

─────────────────────────────────────────────

## SQL SCHEMA

Database (`store.db`) dicipta automatik dengan struktur:

```sql
CREATE TABLE items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    price REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT,
    item_name TEXT NOT NULL,
    price REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT NOT NULL
);
```

Status order yang mungkin: `Pending` → `Proof Sent` → `Paid`

─────────────────────────────────────────────

## NOTA PRESTASI (RESPON PANTAS)

- Semua operasi I/O (database, network) menggunakan **async/await**
  sepenuhnya — bot tidak pernah "block" walau ada banyak pengguna
  serentak.
- `callback.answer()` dipanggil **serta-merta** apabila butang
  ditekan supaya tiada "loading" di sisi pengguna.
- `aiosqlite` digunakan (bukan `sqlite3` biasa) supaya operasi
  database tidak menyekat event loop.
- Tiada `time.sleep()` atau operasi blocking lain di mana-mana
  bahagian kod.

─────────────────────────────────────────────

## TROUBLESHOOTING

| Masalah | Penyelesaian |
|---|---|
| `BOT_TOKEN belum ditetapkan` | Edit `config.py` atau set env var `BOT_TOKEN` |
| QR Code tidak terhantar | Pastikan `assets/qrcode.png` wujud ATAU `QR_CODE_URL` betul |
| Butang item tidak muncul | Pastikan sudah guna `/add` dan masukkan harga |
| `/send` tidak berfungsi | Pastikan ia digunakan sebagai **reply** kepada mesej |
| Bot tidak respon | Semak `bot.log` untuk ralat |
