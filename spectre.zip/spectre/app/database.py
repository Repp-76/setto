"""
app/database.py
---------------
SQLite database initialisation, connection pooling, and schema setup.
"""

import sqlite3
import json
import os
from flask import g


def get_db(app=None):
    """
    Return the database connection for the current application context.
    Creates the connection on first call within a request context.
    """
    from flask import current_app
    if app is None:
        app = current_app

    if "db" not in g:
        g.db = sqlite3.connect(
            app.config["DATABASE"],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row  # dict-like access to columns
        g.db.execute("PRAGMA journal_mode=WAL")   # better concurrency
        g.db.execute("PRAGMA foreign_keys=ON")    # enforce FK constraints

    return g.db


def init_db(app):
    """
    Initialise the database schema and seed default data if the database
    does not yet exist.
    """
    db_path = app.config["DATABASE"]
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    first_run = not os.path.exists(db_path)

    with app.app_context():
        with sqlite3.connect(db_path) as con:
            con.row_factory = sqlite3.Row
            con.execute("PRAGMA foreign_keys=ON")
            _create_schema(con)
            if first_run:
                _seed_data(con)
                app.logger.info("Database seeded with default OSINT categories and resources.")


def _create_schema(con):
    """Create all tables if they do not already exist."""
    con.executescript("""
        -- Categories: supports unlimited nesting via parent_id self-reference
        CREATE TABLE IF NOT EXISTS categories (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            slug        TEXT    NOT NULL UNIQUE,
            description TEXT,
            parent_id   INTEGER REFERENCES categories(id) ON DELETE CASCADE,
            icon        TEXT    DEFAULT 'folder',
            sort_order  INTEGER DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Resources: individual OSINT tools / links
        CREATE TABLE IF NOT EXISTS resources (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            description TEXT,
            url         TEXT    NOT NULL,
            category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
            tags        TEXT    DEFAULT '[]',   -- JSON array of strings
            status      TEXT    DEFAULT 'active' CHECK(status IN ('active','inactive','unknown')),
            free        INTEGER DEFAULT 1,      -- 1 = free, 0 = paid
            requires_account INTEGER DEFAULT 0,
            added_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Usage tracking (anonymous click events)
        CREATE TABLE IF NOT EXISTS usage_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            resource_id INTEGER REFERENCES resources(id) ON DELETE CASCADE,
            logged_at   DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        -- Indexes for fast tree and search queries
        CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_id);
        CREATE INDEX IF NOT EXISTS idx_resources_category ON resources(category_id);
        CREATE INDEX IF NOT EXISTS idx_resources_status  ON resources(status);
    """)
    con.commit()


# ── Seed data ──────────────────────────────────────────────────────────────────

def _seed_data(con):
    """
    Insert a comprehensive set of OSINT categories and resources.
    All resources link to publicly accessible, legal open-source intelligence tools.
    """

    # Helper to insert a category and return its id
    def cat(name, slug, desc, parent=None, icon="folder", order=0):
        cur = con.execute(
            "INSERT INTO categories (name,slug,description,parent_id,icon,sort_order) VALUES (?,?,?,?,?,?)",
            (name, slug, desc, parent, icon, order)
        )
        con.commit()
        return cur.lastrowid

    # Helper to insert a resource
    def res(name, desc, url, cat_id, tags=None, free=1, account=0):
        if tags is None:
            tags = []
        con.execute(
            "INSERT INTO resources (name,description,url,category_id,tags,free,requires_account) VALUES (?,?,?,?,?,?,?)",
            (name, desc, url, cat_id, json.dumps(tags), free, account)
        )

    # ── Root categories ────────────────────────────────────────────────────────
    people     = cat("People & Identity",     "people-identity",     "Research individuals through usernames, email, phone, and public records.", icon="user", order=1)
    domain     = cat("Domain & Network",      "domain-network",      "Investigate domains, IPs, DNS records, certificates, and network infrastructure.", icon="network", order=2)
    social     = cat("Social Media",          "social-media",        "Analyse social network profiles, posts, and connections.", icon="share", order=3)
    threat     = cat("Threat Intelligence",   "threat-intelligence", "Cybersecurity threat data, malware analysis, breach monitoring.", icon="shield", order=4)
    geo        = cat("Geolocation & Maps",    "geo-maps",            "Satellite imagery, geolocation, aviation, maritime, and mapping tools.", icon="map-pin", order=5)
    business   = cat("Business & Finance",    "business-finance",    "Company research, filings, crypto, and financial intelligence.", icon="briefcase", order=6)
    media      = cat("Media & Archives",      "media-archives",      "Image research, metadata analysis, document investigation, web archives.", icon="archive", order=7)
    gov        = cat("Government & Legal",    "gov-legal",           "Government records, court documents, public registries.", icon="landmark", order=8)
    search     = cat("Search & Discovery",    "search-discovery",    "Search engines, data aggregators, and general discovery tools.", icon="search", order=9)
    darkweb    = cat("Dark Web & Monitoring", "dark-web",            "Dark web monitoring and exposure analysis tools.", icon="eye-off", order=10)

    # ── Sub-categories: People & Identity ────────────────────────────────────
    username   = cat("Username Research",   "username",   "Find accounts across platforms using a username.",           parent=people, icon="at-sign", order=1)
    email_cat  = cat("Email Research",      "email",      "Investigate email addresses and their digital footprint.",   parent=people, icon="mail", order=2)
    phone_cat  = cat("Phone Research",      "phone",      "Reverse phone lookup and carrier intelligence.",             parent=people, icon="phone", order=3)
    people_s   = cat("People Search",       "people-search","Public records people search engines.",                   parent=people, icon="users", order=4)

    # ── Sub-categories: Domain & Network ─────────────────────────────────────
    ip_cat     = cat("IP Research",          "ip-research",  "IP geolocation, reputation, and WHOIS lookup.",          parent=domain, icon="server", order=1)
    dns_cat    = cat("DNS Intelligence",     "dns",           "DNS records, zone transfers, and historical DNS data.",  parent=domain, icon="git-branch", order=2)
    whois_cat  = cat("WHOIS & Registration","whois",         "Domain ownership and registration history.",             parent=domain, icon="file-text", order=3)
    cert_cat   = cat("Certificate Transparency","cert-transparency","SSL/TLS certificate logs and analysis.",          parent=domain, icon="lock", order=4)
    net_cat    = cat("Network Intelligence","network-intel", "Port scanning services, BGP, ASN, and routing data.",    parent=domain, icon="activity", order=5)

    # ── Sub-categories: Social Media ─────────────────────────────────────────
    sm_analysis= cat("Profile Analysis",    "sm-analysis",  "Analyse and archive social media profiles.",              parent=social, icon="bar-chart-2", order=1)
    sm_search  = cat("Social Search",       "sm-search",    "Cross-platform social media search tools.",               parent=social, icon="search", order=2)

    # ── Sub-categories: Threat Intelligence ──────────────────────────────────
    malware    = cat("Malware Analysis",    "malware",      "Sandbox and static analysis of malicious files/URLs.",    parent=threat, icon="bug", order=1)
    breach_cat = cat("Breach Monitoring",   "breach",       "Check for credential and data breaches.",                 parent=threat, icon="alert-triangle", order=2)
    url_cat    = cat("URL & Link Analysis", "url-analysis", "Analyse suspicious links and URLs for threats.",          parent=threat, icon="link", order=3)
    footprint  = cat("Digital Footprint",   "digital-footprint","Assess an organisation or individual's attack surface.",parent=threat, icon="crosshair", order=4)

    # ── Sub-categories: Geolocation & Maps ───────────────────────────────────
    geo_tools  = cat("Geolocation Tools",   "geo-tools",    "Geolocate images, IPs, and objects using visual clues.", parent=geo, icon="map-pin", order=1)
    aviation   = cat("Aviation",            "aviation",     "Live and historical aircraft tracking.",                  parent=geo, icon="send", order=2)
    maritime   = cat("Maritime",            "maritime",     "Vessel tracking, AIS data, and port intelligence.",       parent=geo, icon="anchor", order=3)
    satellite  = cat("Satellite & Imagery", "satellite",    "Satellite imagery, terrain analysis, and earth observation.",parent=geo, icon="globe", order=4)

    # ── Sub-categories: Business & Finance ───────────────────────────────────
    company_s  = cat("Company Search",      "company-search","Company registries and corporate intelligence.",         parent=business, icon="building", order=1)
    crypto_cat = cat("Cryptocurrency",      "cryptocurrency","Blockchain analysis and crypto address investigation.",  parent=business, icon="dollar-sign", order=2)
    vehicle    = cat("Vehicle Research",    "vehicle",      "Vehicle registration and VIN lookup services.",           parent=business, icon="truck", order=3)

    # ── Sub-categories: Media & Archives ─────────────────────────────────────
    image_cat  = cat("Image Research",      "image-research","Reverse image search and visual intelligence.",          parent=media, icon="image", order=1)
    meta_cat   = cat("Metadata Analysis",   "metadata",     "Extract metadata from documents, images, and files.",    parent=media, icon="layers", order=2)
    doc_cat    = cat("Document Research",   "document",     "Document intelligence and file analysis tools.",         parent=media, icon="file", order=3)
    archive_c  = cat("Web Archives",        "web-archives", "Historical snapshots of websites and online content.",   parent=media, icon="clock", order=4)

    # ── Resources: Username Research ─────────────────────────────────────────
    res("Sherlock",          "Hunt down social media accounts across 400+ platforms by username.",
        "https://github.com/sherlock-project/sherlock", username, ["cli","github","python"], free=1)
    res("WhatsMyName",       "Cross-platform username availability and existence checker.",
        "https://whatsmyname.app", username, ["web","username"], free=1)
    res("Namechk",           "Check username/domain availability across hundreds of social networks.",
        "https://namechk.com", username, ["web","domain"], free=1)
    res("UserSearch.org",    "Search for a username across 2000+ social networks instantly.",
        "https://usersearch.org", username, ["web"], free=1)
    res("Instant Username Search","Real-time username availability checker across social platforms.",
        "https://instantusername.com", username, ["web","realtime"], free=1)

    # ── Resources: Email Research ─────────────────────────────────────────────
    res("Hunter.io",         "Find professional email addresses associated with a domain or company.",
        "https://hunter.io", email_cat, ["email","domain","b2b"], free=0, account=1)
    res("Have I Been Pwned", "Check if an email address has appeared in known data breaches.",
        "https://haveibeenpwned.com", email_cat, ["breach","security"], free=1)
    res("EmailRep.io",       "Analyse email address reputation, history, and risk scoring.",
        "https://emailrep.io", email_cat, ["reputation","api"], free=1)
    res("MXToolbox",         "Email header analysis, deliverability, blacklist, and MX record checks.",
        "https://mxtoolbox.com", email_cat, ["mx","dns","headers"], free=1)
    res("Epieos",            "Reverse email lookup — find accounts and services linked to an email.",
        "https://epieos.com", email_cat, ["reverse","social"], free=1)

    # ── Resources: Phone Research ─────────────────────────────────────────────
    res("NumLookup",         "Free reverse phone number lookup with carrier and line type info.",
        "https://www.numlookup.com", phone_cat, ["reverse","carrier"], free=1)
    res("PhoneInfoga",       "Advanced phone number OSINT — gather info using public sources.",
        "https://github.com/sundowndev/phoneinfoga", phone_cat, ["cli","github"], free=1)
    res("Truecaller",        "Crowd-sourced phone number and caller ID database.",
        "https://www.truecaller.com", phone_cat, ["caller-id","crowdsourced"], free=0, account=1)
    res("National Cellular Directory","Reverse phone lookup for US numbers.",
        "https://www.nationalcellulardirectory.com", phone_cat, ["us","reverse"], free=0)

    # ── Resources: People Search ──────────────────────────────────────────────
    res("Spokeo",            "People search aggregator — addresses, relatives, social profiles.",
        "https://www.spokeo.com", people_s, ["aggregator","us"], free=0)
    res("Pipl",              "Deep web people search across public records and social data.",
        "https://pipl.com", people_s, ["deep-web","api"], free=0, account=1)
    res("TinEye",            "Reverse image search to find where a photo appears online.",
        "https://tineye.com", people_s, ["image","reverse"], free=1)
    res("FamilyTreeNow",     "Free genealogy and public records search for individuals.",
        "https://www.familytreenow.com", people_s, ["genealogy","free","us"], free=1)

    # ── Resources: IP Research ────────────────────────────────────────────────
    res("Shodan",            "Search engine for internet-connected devices — the hacker's Google.",
        "https://www.shodan.io", ip_cat, ["iot","scanning","api"], free=0, account=1)
    res("Censys",            "Scan and search the global internet for hosts, certificates, and services.",
        "https://search.censys.io", ip_cat, ["scanning","certificates"], free=0, account=1)
    res("IPInfo.io",         "IP geolocation, ASN, organisation, and abuse contact lookup.",
        "https://ipinfo.io", ip_cat, ["geolocation","asn","api"], free=1)
    res("AbuseIPDB",         "Community-driven IP abuse reporting and reputation database.",
        "https://www.abuseipdb.com", ip_cat, ["reputation","abuse","community"], free=1)
    res("GreyNoise",         "Analyse internet background noise — separate targeted attacks from mass scanners.",
        "https://viz.greynoise.io", ip_cat, ["noise","threat","api"], free=0, account=1)
    res("Hurricane Electric BGP","BGP routing and ASN lookup with prefix visibility.",
        "https://bgp.he.net", ip_cat, ["bgp","asn","routing"], free=1)

    # ── Resources: DNS Intelligence ───────────────────────────────────────────
    res("SecurityTrails",    "Historical DNS records, subdomains, associated IPs, and WHOIS history.",
        "https://securitytrails.com", dns_cat, ["historical","subdomains","api"], free=0, account=1)
    res("DNSdumpster",       "Free domain research tool — DNS recon and host enumeration.",
        "https://dnsdumpster.com", dns_cat, ["recon","subdomains","free"], free=1)
    res("ViewDNS.info",      "Comprehensive DNS lookup tool with reverse IP, WHOIS, and more.",
        "https://viewdns.info", dns_cat, ["reverse","lookup","free"], free=1)
    res("Passive DNS (CIRCL)","Passive DNS database from CIRCL — Luxembourg CERT.",
        "https://www.circl.lu/services/passive-dns/", dns_cat, ["passive","historical"], free=1)

    # ── Resources: WHOIS & Registration ──────────────────────────────────────
    res("ICANN WHOIS",       "Official ICANN WHOIS lookup for domain registration data.",
        "https://lookup.icann.org", whois_cat, ["official","domain","registration"], free=1)
    res("DomainTools WHOIS", "Advanced WHOIS with domain history, screenshots, and reverse lookups.",
        "https://whois.domaintools.com", whois_cat, ["history","reverse","premium"], free=0)
    res("ARIN WHOIS",        "ARIN's WHOIS for North American IP address and ASN registration data.",
        "https://search.arin.net/rdap/", whois_cat, ["arin","ip","asn"], free=1)
    res("Whoxy",             "Reverse WHOIS — find all domains registered by an email or name.",
        "https://www.whoxy.com", whois_cat, ["reverse","email","registrant"], free=1)

    # ── Resources: Certificate Transparency ──────────────────────────────────
    res("crt.sh",            "Search Certificate Transparency logs to find subdomains and certs.",
        "https://crt.sh", cert_cat, ["ssl","subdomains","free"], free=1)
    res("Cert Spotter",      "Monitor and search certificate issuances in real time.",
        "https://sslmate.com/certspotter/", cert_cat, ["monitoring","ssl"], free=0, account=1)
    res("Facebook CT API",   "Facebook's Certificate Transparency monitoring API.",
        "https://developers.facebook.com/tools/ct/", cert_cat, ["api","facebook","ssl"], free=1)

    # ── Resources: Network Intelligence ──────────────────────────────────────
    res("Shodan Internetdb", "Fast, API-accessible IP intelligence from Shodan.",
        "https://internetdb.shodan.io", net_cat, ["api","shodan","fast"], free=1)
    res("RIPE NCC",          "European internet registry — IP allocations and routing policy.",
        "https://www.ripe.net", net_cat, ["rir","europe","routing"], free=1)
    res("Netcraft",          "Web server, hosting provider, and site history investigation.",
        "https://sitereport.netcraft.com", net_cat, ["hosting","history","phishing"], free=1)
    res("FOFA",              "Chinese cyberspace asset search engine for internet-exposed services.",
        "https://fofa.info", net_cat, ["scanning","china","api"], free=0, account=1)

    # ── Resources: Social Media ───────────────────────────────────────────────
    res("Social Searcher",   "Real-time social media search across all major networks.",
        "https://www.social-searcher.com", sm_search, ["realtime","multi-platform"], free=1)
    res("Twint",             "Advanced Twitter scraping tool without API — archived accounts too.",
        "https://github.com/twintproject/twint", sm_analysis, ["twitter","cli","github"], free=1)
    res("OSINTgram",         "Instagram OSINT tool — extract followers, hashtags, and profile data.",
        "https://github.com/Datalux/Osintgram", sm_analysis, ["instagram","cli","github"], free=1)
    res("IntelX",            "Intelligence X — search darknet, leaks, paste sites, and social data.",
        "https://intelx.io", sm_search, ["leaks","darknet","api"], free=0, account=1)

    # ── Resources: Malware Analysis ───────────────────────────────────────────
    res("VirusTotal",        "Analyse suspicious files, URLs, domains with 70+ antivirus engines.",
        "https://www.virustotal.com", malware, ["antivirus","url","api"], free=1, account=1)
    res("Any.run",           "Interactive online malware sandbox with real-time execution.",
        "https://app.any.run", malware, ["sandbox","interactive"], free=0, account=1)
    res("Hybrid Analysis",   "Free online malware analysis service powered by Falcon Sandbox.",
        "https://www.hybrid-analysis.com", malware, ["sandbox","crowdstrike"], free=1, account=1)
    res("Joe Sandbox",       "Deep malware analysis with full behavioural and static reports.",
        "https://www.joesandbox.com", malware, ["sandbox","detailed"], free=0, account=1)
    res("MalwareBazaar",     "Abuse.ch malware sample repository for threat researchers.",
        "https://bazaar.abuse.ch", malware, ["samples","abuse-ch","free"], free=1)

    # ── Resources: Breach Monitoring ─────────────────────────────────────────
    res("Have I Been Pwned (API)","API access to breach data for developers and researchers.",
        "https://haveibeenpwned.com/API/v3", breach_cat, ["api","developer"], free=0)
    res("Snusbase",          "Database breach search engine for security research.",
        "https://snusbase.com", breach_cat, ["database","search"], free=0, account=1)
    res("LeakPeek",          "Search across leaked databases and breach compilations.",
        "https://leakpeek.com", breach_cat, ["leaks","search"], free=0)
    res("DeHashed",          "Advanced search engine for compromised account data.",
        "https://dehashed.com", breach_cat, ["search","api"], free=0, account=1)

    # ── Resources: URL Analysis ───────────────────────────────────────────────
    res("URLScan.io",        "Scan and analyse websites — screenshots, DOM, requests, technologies.",
        "https://urlscan.io", url_cat, ["scan","screenshot","api"], free=1)
    res("URLhaus",           "Abuse.ch database of malicious URLs used for malware distribution.",
        "https://urlhaus.abuse.ch", url_cat, ["malware","abuse-ch","api"], free=1)
    res("PhishTank",         "Community anti-phishing site — submit and verify phishing URLs.",
        "https://www.phishtank.com", url_cat, ["phishing","community"], free=1)
    res("Unshorten.it",      "Expand shortened URLs to see the final destination safely.",
        "https://unshorten.it", url_cat, ["redirect","expand","safety"], free=1)

    # ── Resources: Digital Footprint ──────────────────────────────────────────
    res("SpiderFoot",        "Automated OSINT reconnaissance — generates attack surface maps.",
        "https://github.com/smicallef/spiderfoot", footprint, ["automation","cli","github"], free=1)
    res("Maltego Community", "Visual link analysis platform for data relationships and footprints.",
        "https://www.maltego.com/maltego-community/", footprint, ["visual","graph","community"], free=1, account=1)
    res("theHarvester",      "Gather emails, names, subdomains, IPs, and URLs from public sources.",
        "https://github.com/laramies/theHarvester", footprint, ["cli","github","recon"], free=1)
    res("Recon-ng",          "Full-featured web reconnaissance framework with modular architecture.",
        "https://github.com/lanmaster53/recon-ng", footprint, ["framework","cli","github"], free=1)

    # ── Resources: Geolocation ────────────────────────────────────────────────
    res("GeoGuessr GeoTips", "Community-maintained geolocation hinting resource.",
        "https://geotips.net", geo_tools, ["community","tips"], free=1)
    res("SunCalc",           "Determine time and date from shadow angles and sun position.",
        "https://www.suncalc.org", geo_tools, ["sun","shadow","date"], free=1)
    res("What3Words",        "3-word address geolocation system with 3m² precision.",
        "https://what3words.com", geo_tools, ["address","precise"], free=1)
    res("Overpass Turbo",    "OpenStreetMap data query and extraction tool.",
        "https://overpass-turbo.eu", geo_tools, ["osm","query","openstreetmap"], free=1)

    # ── Resources: Aviation ───────────────────────────────────────────────────
    res("FlightAware",       "Live flight tracking, history, and aircraft registration data.",
        "https://www.flightaware.com", aviation, ["live","history","tracking"], free=1)
    res("Flightradar24",     "Real-time flight tracker with ADS-B coverage worldwide.",
        "https://www.flightradar24.com", aviation, ["realtime","ads-b","worldwide"], free=1)
    res("ADS-B Exchange",    "Unfiltered, community-driven ADS-B flight data — no government blocks.",
        "https://www.adsbexchange.com", aviation, ["ads-b","unfiltered","community"], free=1)
    res("OpenSky Network",   "Open-source air traffic surveillance research network.",
        "https://opensky-network.org", aviation, ["research","api","open-source"], free=1)

    # ── Resources: Maritime ───────────────────────────────────────────────────
    res("MarineTraffic",     "Global AIS vessel tracking — positions, routes, and port calls.",
        "https://www.marinetraffic.com", maritime, ["ais","live","vessels"], free=1)
    res("VesselFinder",      "Free AIS-based vessel tracking with voyage data.",
        "https://www.vesselfinder.com", maritime, ["ais","free"], free=1)
    res("FleetMon",          "Track ships, ports, and maritime events globally.",
        "https://www.fleetmon.com", maritime, ["fleet","ports","events"], free=1)
    res("PortWatch",         "Vessel and port monitoring with anomaly detection.",
        "https://portwatch.imf.org", maritime, ["ports","imf","analytics"], free=1)

    # ── Resources: Satellite & Imagery ───────────────────────────────────────
    res("Google Earth",      "High-resolution satellite imagery and 3D terrain exploration.",
        "https://earth.google.com/web/", satellite, ["satellite","3d","google"], free=1)
    res("Sentinel Hub",      "ESA Copernicus satellite data — multispectral, SAR, and historical.",
        "https://www.sentinel-hub.com", satellite, ["esa","copernicus","multispectral"], free=0, account=1)
    res("NASA Worldview",    "Browse NASA's satellite imagery archive with temporal filtering.",
        "https://worldview.earthdata.nasa.gov", satellite, ["nasa","archive","free"], free=1)
    res("Planet Labs Explorer","Sub-daily commercial satellite imagery for any location.",
        "https://www.planet.com/explorer/", satellite, ["commercial","sub-daily"], free=0, account=1)

    # ── Resources: Company Search ─────────────────────────────────────────────
    res("OpenCorporates",    "World's largest database of company information — 200M+ companies.",
        "https://opencorporates.com", company_s, ["global","200M","open-data"], free=1)
    res("Companies House UK","Official UK company registry — filings, directors, financials.",
        "https://find-and-update.company-information.service.gov.uk", company_s, ["uk","official","filings"], free=1)
    res("SEC EDGAR",         "US Securities and Exchange Commission company filings database.",
        "https://www.sec.gov/edgar/", company_s, ["us","sec","filings","public"], free=1)
    res("GLEIF",             "Global Legal Entity Identifier Foundation — LEI register.",
        "https://search.gleif.org", company_s, ["lei","global","financial"], free=1)

    # ── Resources: Cryptocurrency ─────────────────────────────────────────────
    res("Blockchain Explorer","Bitcoin blockchain browser — transactions, addresses, blocks.",
        "https://www.blockchain.com/explorer", crypto_cat, ["bitcoin","blockchain","free"], free=1)
    res("Etherscan",         "Ethereum blockchain explorer — transactions, tokens, smart contracts.",
        "https://etherscan.io", crypto_cat, ["ethereum","erc20","api"], free=1)
    res("Chainalysis Reactor","Professional blockchain analytics for law enforcement and compliance.",
        "https://www.chainalysis.com/chainalysis-reactor/", crypto_cat, ["analytics","compliance","enterprise"], free=0)
    res("CipherTrace",       "Cryptocurrency AML and blockchain analytics intelligence.",
        "https://ciphertrace.com", crypto_cat, ["aml","analytics"], free=0)
    res("Crystal Blockchain","Visual crypto transaction tracing and risk scoring.",
        "https://crystalblockchain.com", crypto_cat, ["visual","tracing","risk"], free=0, account=1)

    # ── Resources: Vehicle Research ───────────────────────────────────────────
    res("VINCheck (NHTSA)",  "Free VIN check from NHTSA — recalls, complaints, and safety ratings.",
        "https://www.nhtsa.gov/vehicle", vehicle, ["vin","nhtsa","us","free"], free=1)
    res("AutoCheck",         "Vehicle history report from Experian — accidents, titles, odometer.",
        "https://www.autocheck.com", vehicle, ["history","experian","us"], free=0)
    res("Carfax",            "Vehicle history report — accidents, service records, ownership history.",
        "https://www.carfax.com", vehicle, ["history","us","canada"], free=0)

    # ── Resources: Image Research ─────────────────────────────────────────────
    res("Google Images",     "Reverse image search — find visually similar images and sources.",
        "https://images.google.com", image_cat, ["reverse","google","free"], free=1)
    res("Yandex Images",     "Yandex reverse image search — often finds matches Google misses.",
        "https://yandex.com/images/", image_cat, ["reverse","yandex","faces"], free=1)
    res("PimEyes",           "AI-powered face recognition reverse image search engine.",
        "https://pimeyes.com", image_cat, ["ai","face-recognition"], free=0, account=1)
    res("Forensically",      "Free image forensics tool — clone detection, metadata, error level analysis.",
        "https://29a.ch/photo-forensics/", image_cat, ["forensics","ela","free"], free=1)
    res("FotoForensics",     "JPEG error level analysis and metadata extraction for image verification.",
        "https://fotoforensics.com", image_cat, ["ela","jpeg","metadata"], free=1)

    # ── Resources: Metadata Analysis ─────────────────────────────────────────
    res("ExifTool",          "Read and write metadata in image, audio, video, and document files.",
        "https://exiftool.org", meta_cat, ["exif","cli","metadata"], free=1)
    res("Jeffrey's Exif Viewer","Web-based EXIF metadata extraction and GPS coordinate mapper.",
        "https://exif.regex.info/exif.cgi", meta_cat, ["exif","gps","web"], free=1)
    res("FOCA",              "Metadata extraction from office documents — emails, authors, software.",
        "https://github.com/ElevenPaths/FOCA", meta_cat, ["documents","email","github"], free=1)
    res("Metagoofil",        "Metadata extractor for public documents via Google dork queries.",
        "https://github.com/laramies/metagoofil", meta_cat, ["google","dork","cli"], free=1)

    # ── Resources: Document Research ─────────────────────────────────────────
    res("DocumentCloud",     "Platform for journalists to upload, analyse, and share documents.",
        "https://www.documentcloud.org", doc_cat, ["journalism","ocr","public"], free=1)
    res("Google Docs Viewer","View documents (PDF, DOCX, XLSX) directly in the browser.",
        "https://docs.google.com/viewer", doc_cat, ["viewer","google","free"], free=1)
    res("Scribd",            "Large repository of public documents, books, and academic papers.",
        "https://www.scribd.com", doc_cat, ["documents","books"], free=0, account=1)

    # ── Resources: Web Archives ───────────────────────────────────────────────
    res("Wayback Machine",   "Archive.org's web archive — browse 800+ billion saved web pages.",
        "https://web.archive.org", archive_c, ["archive","history","free"], free=1)
    res("CachedView",        "View Google, Bing, and Wayback cached versions of any URL.",
        "https://cachedview.nl", archive_c, ["cache","google","bing"], free=1)
    res("Archive.ph",        "Save and retrieve snapshots of web pages; resistant to link rot.",
        "https://archive.ph", archive_c, ["snapshot","persistent"], free=1)
    res("TimeTravel (Memento)","Cross-archive time travel for historical web page retrieval.",
        "https://timetravel.mementoweb.org", archive_c, ["memento","multi-archive"], free=1)

    # ── Resources: Government & Legal ────────────────────────────────────────
    gov_records = cat("Public Records",     "public-records",  "Public record databases and government registries.", parent=gov, icon="file-text", order=1)
    court_cat   = cat("Court Records",      "court-records",   "Judicial documents and court filing databases.",     parent=gov, icon="scale", order=2)

    res("PACER",             "US federal court case documents and electronic filing system.",
        "https://pacer.uscourts.gov", court_cat, ["us","federal","court"], free=0, account=1)
    res("CourtListener",     "Free law and federal court opinions database from Free Law Project.",
        "https://www.courtlistener.com", court_cat, ["free","us","opinions"], free=1)
    res("RECAP Archive",     "Crowd-sourced PACER court document repository — free access.",
        "https://www.courtlistener.com/recap/", court_cat, ["free","recap","pacer"], free=1)

    res("Data.gov",          "US government open data portal — datasets across agencies.",
        "https://data.gov", gov_records, ["us","open-data","government"], free=1)
    res("Sunlight Foundation","Transparency and open government data tools and APIs.",
        "https://sunlightfoundation.com", gov_records, ["transparency","api"], free=1)
    res("FOIA.gov",          "US Freedom of Information Act portal — submit and track requests.",
        "https://www.foia.gov", gov_records, ["foia","us","transparency"], free=1)

    # ── Resources: Search & Discovery ────────────────────────────────────────
    se_cat   = cat("Search Engines",    "search-engines",   "General and specialised search engines for OSINT.", parent=search, icon="search", order=1)
    dork_cat = cat("Google Dorking",    "google-dorking",   "Advanced search operator techniques and tools.",    parent=search, icon="terminal", order=2)

    res("Google Advanced Search","Refined Google search with date, file type, and region filters.",
        "https://www.google.com/advanced_search", se_cat, ["google","advanced","free"], free=1)
    res("Bing",              "Microsoft's search engine — often indexes different results than Google.",
        "https://www.bing.com", se_cat, ["bing","microsoft"], free=1)
    res("DuckDuckGo",        "Privacy-respecting search engine with Tor-accessible .onion version.",
        "https://duckduckgo.com", se_cat, ["privacy","tor-onion"], free=1)
    res("Ahmia",             "Search engine for Tor hidden services (.onion sites).",
        "https://ahmia.fi", se_cat, ["tor","onion","dark-web"], free=1)
    res("Startpage",         "Google results with complete anonymity — no tracking.",
        "https://www.startpage.com", se_cat, ["privacy","google-proxy"], free=1)

    res("Google Hacking DB (GHDB)","Exploit-DB's collection of Google dork queries for OSINT.",
        "https://www.exploit-db.com/google-hacking-database", dork_cat, ["dorks","exploit-db","google"], free=1)
    res("Pentest-Tools Dork Generator","Generate Google dork queries for reconnaissance.",
        "https://pentest-tools.com/information-gathering/google-hacking", dork_cat, ["generator","dorks"], free=0, account=1)

    # ── Resources: Dark Web Monitoring ───────────────────────────────────────
    res("DarkOwl",           "Largest commercially available darknet data intelligence platform.",
        "https://www.darkowl.com", darkweb, ["commercial","darknet","api"], free=0, account=1)
    res("Tor2Web",           "Access Tor hidden services without Tor browser — for research.",
        "https://www.tor2web.fi", darkweb, ["tor","access","research"], free=1)
    res("OnionScan",         "Scan hidden services for security vulnerabilities and OPSEC failures.",
        "https://github.com/s-rah/onionscan", darkweb, ["scan","tor","github"], free=1)
    res("Dark Web ID",       "Dark web credential monitoring for organisations.",
        "https://darkwebid.com", darkweb, ["monitoring","credentials","b2b"], free=0, account=1)
    res("Intelligence X",   "Search across Tor, I2P, and leak sites for compromised data.",
        "https://intelx.io", darkweb, ["search","tor","leaks","api"], free=0, account=1)

    con.commit()
