"""
handlers/__init__.py
─────────────────────────────────────────────
Pakej handlers. Fail ini sengaja dikosongkan kecuali
untuk dokumentasi ringkas — pendaftaran router
dilakukan secara terus di main.py.
"""
