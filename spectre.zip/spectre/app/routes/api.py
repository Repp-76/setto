"""
app/routes/api.py
-----------------
JSON API — all resources from a category include descendant sub-categories.
"""

from flask import Blueprint, jsonify, request
from ..database import get_db
import json

api_bp = Blueprint("api", __name__)


def _row_to_dict(row):
    return dict(row)


def _build_tree(categories, parent_id=None):
    nodes = []
    for cat in categories:
        if cat["parent_id"] == parent_id:
            node = _row_to_dict(cat)
            node["children"] = _build_tree(categories, parent_id=cat["id"])
            nodes.append(node)
    nodes.sort(key=lambda n: n.get("sort_order", 0))
    return nodes


def _get_all_descendant_ids(db, cat_id):
    """
    Recursively collect the given category id plus all child category ids.
    Used so clicking a parent category shows ALL resources in its subtree.
    """
    ids = [cat_id]
    children = db.execute(
        "SELECT id FROM categories WHERE parent_id=?", (cat_id,)
    ).fetchall()
    for child in children:
        ids.extend(_get_all_descendant_ids(db, child["id"]))
    return ids


def _parse_tags(rd):
    try:
        rd["tags"] = json.loads(rd.get("tags") or "[]")
    except (json.JSONDecodeError, TypeError):
        rd["tags"] = []
    return rd


# ── Tree ──────────────────────────────────────────────────────────────────────

@api_bp.route("/tree")
def get_tree():
    """Full nested category tree. resource_count = direct + all descendants."""
    db = get_db()

    # Get all categories with their direct resource counts
    cats = db.execute("""
        SELECT c.id, c.name, c.slug, c.description, c.parent_id, c.icon, c.sort_order,
               COUNT(r.id) as direct_count
        FROM categories c
        LEFT JOIN resources r ON r.category_id = c.id AND r.status = 'active'
        GROUP BY c.id
        ORDER BY c.sort_order, c.name
    """).fetchall()

    cats_list = [_row_to_dict(c) for c in cats]

    # Build a lookup for fast total count computation
    direct_counts = {c["id"]: c["direct_count"] for c in cats_list}

    def total_count(node_id):
        total = direct_counts.get(node_id, 0)
        for c in cats_list:
            if c["parent_id"] == node_id:
                total += total_count(c["id"])
        return total

    for c in cats_list:
        c["resource_count"] = total_count(c["id"])

    tree = _build_tree(cats_list)
    return jsonify(tree)


# ── Category detail ───────────────────────────────────────────────────────────

@api_bp.route("/categories/<int:cat_id>")
def get_category(cat_id):
    """
    Return category info + ALL resources in this category AND every
    sub-category beneath it (recursive). Also returns sub-category list
    so the frontend can show a breakdown.
    """
    db = get_db()

    cat = db.execute("SELECT * FROM categories WHERE id=?", (cat_id,)).fetchone()
    if not cat:
        return jsonify({"error": "Category not found"}), 404

    cat_dict = _row_to_dict(cat)

    # All descendant category ids (includes self)
    all_ids = _get_all_descendant_ids(db, cat_id)
    placeholders = ",".join("?" * len(all_ids))

    # Resources across entire subtree
    resources = db.execute(f"""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status,
               r.free, r.requires_account, r.added_at,
               c.id as cat_id, c.name as cat_name
        FROM resources r
        JOIN categories c ON c.id = r.category_id
        WHERE r.category_id IN ({placeholders}) AND r.status='active'
        ORDER BY c.sort_order, c.name, r.name
    """, all_ids).fetchall()

    # Sub-categories (direct children only, for section headers)
    sub_cats = db.execute("""
        SELECT id, name, slug, icon, sort_order,
               (SELECT COUNT(*) FROM resources WHERE category_id = c.id AND status='active') as res_count
        FROM categories c
        WHERE parent_id=?
        ORDER BY sort_order, name
    """, (cat_id,)).fetchall()

    res_list = [_parse_tags(_row_to_dict(r)) for r in resources]
    sub_list = [_row_to_dict(s) for s in sub_cats]

    cat_dict["resources"]      = res_list
    cat_dict["sub_categories"] = sub_list
    cat_dict["total_count"]    = len(res_list)
    return jsonify(cat_dict)


# ── Search ────────────────────────────────────────────────────────────────────

@api_bp.route("/search")
def search():
    q = request.args.get("q", "").strip()
    if len(q) < 2:
        return jsonify({"categories": [], "resources": []})

    db   = get_db()
    like = f"%{q}%"

    cats = db.execute("""
        SELECT id, name, slug, description, icon
        FROM categories
        WHERE name LIKE ? OR description LIKE ?
        ORDER BY name LIMIT 20
    """, (like, like)).fetchall()

    resources = db.execute("""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status, r.free,
               c.name as category_name, c.id as category_id, c.slug as category_slug
        FROM resources r
        JOIN categories c ON c.id = r.category_id
        WHERE r.status = 'active'
          AND (r.name LIKE ? OR r.description LIKE ? OR r.tags LIKE ?)
        ORDER BY r.name LIMIT 80
    """, (like, like, like)).fetchall()

    return jsonify({
        "categories": [_row_to_dict(c) for c in cats],
        "resources":  [_parse_tags(_row_to_dict(r)) for r in resources]
    })


# ── Export ────────────────────────────────────────────────────────────────────

@api_bp.route("/export")
def export_data():
    db = get_db()
    cats      = db.execute("SELECT * FROM categories ORDER BY sort_order, name").fetchall()
    resources = db.execute("SELECT * FROM resources ORDER BY category_id, name").fetchall()
    return jsonify({
        "version":    "1.0",
        "categories": [_row_to_dict(c) for c in cats],
        "resources":  [_parse_tags(_row_to_dict(r)) for r in resources]
    })


# ── Stats ─────────────────────────────────────────────────────────────────────

@api_bp.route("/stats")
def stats():
    db = get_db()
    total_res  = db.execute("SELECT COUNT(*) FROM resources WHERE status='active'").fetchone()[0]
    total_cats = db.execute("SELECT COUNT(*) FROM categories").fetchone()[0]
    free_res   = db.execute("SELECT COUNT(*) FROM resources WHERE free=1 AND status='active'").fetchone()[0]
    top_cats   = db.execute("""
        SELECT c.name, c.slug, c.icon, COUNT(ul.id) as hits
        FROM categories c
        LEFT JOIN resources r ON r.category_id = c.id
        LEFT JOIN usage_log ul ON ul.resource_id = r.id
        GROUP BY c.id ORDER BY hits DESC LIMIT 5
    """).fetchall()
    return jsonify({
        "total_resources":  total_res,
        "total_categories": total_cats,
        "free_resources":   free_res,
        "top_categories":   [_row_to_dict(c) for c in top_cats]
    })
