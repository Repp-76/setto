"""
app/utils/validators.py
-----------------------
Input validation and sanitisation using stdlib only (no bleach).
"""

import re
import json
import html
from urllib.parse import urlparse

_SLUG_RE = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
_URL_SCHEMES = {"http", "https"}
_TAG_RE = re.compile(r'<[^>]+>')


def sanitise_text(value: str, max_length: int = 500) -> str:
    if not isinstance(value, str):
        return ""
    cleaned = _TAG_RE.sub('', value)
    cleaned = html.unescape(cleaned)
    return cleaned.strip()[:max_length]


def validate_url(url: str):
    if not isinstance(url, str) or not url.strip():
        return False, "URL is required."
    url = url.strip()
    try:
        parsed = urlparse(url)
        if parsed.scheme not in _URL_SCHEMES:
            return False, f"URL must use http or https."
        if not parsed.netloc:
            return False, "URL must include a domain name."
        return True, ""
    except Exception:
        return False, "Malformed URL."


def validate_slug(slug: str):
    if not isinstance(slug, str) or not slug.strip():
        return False, "Slug is required."
    slug = slug.strip().lower()
    if not _SLUG_RE.match(slug):
        return False, "Slug must contain only lowercase letters, numbers, and hyphens."
    if len(slug) > 80:
        return False, "Slug must be 80 characters or fewer."
    return True, ""


def validate_tags(tags_raw):
    if isinstance(tags_raw, str):
        try:
            tags = json.loads(tags_raw)
        except json.JSONDecodeError:
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
    elif isinstance(tags_raw, list):
        tags = tags_raw
    else:
        return True, [], ""
    if not isinstance(tags, list):
        return False, [], "Tags must be a list."
    if len(tags) > 10:
        return False, [], "Maximum 10 tags allowed."
    clean_tags = [sanitise_text(str(t), 30).lower() for t in tags if sanitise_text(str(t), 30)]
    return True, clean_tags, ""


def validate_resource(data: dict):
    errors = []
    cleaned = {}
    name = sanitise_text(data.get("name", ""), 100)
    if not name:
        errors.append("Resource name is required.")
    cleaned["name"] = name
    cleaned["description"] = sanitise_text(data.get("description", ""), 500)
    url = (data.get("url") or "").strip()
    url_valid, url_err = validate_url(url)
    if not url_valid:
        errors.append(url_err)
    cleaned["url"] = url
    try:
        cleaned["category_id"] = int(data.get("category_id", 0))
        if cleaned["category_id"] <= 0:
            raise ValueError
    except (TypeError, ValueError):
        errors.append("A valid category must be selected.")
    tags_valid, tags, tags_err = validate_tags(data.get("tags", []))
    if not tags_valid:
        errors.append(tags_err)
    cleaned["tags"] = json.dumps(tags)
    status = (data.get("status") or "active").strip().lower()
    if status not in {"active", "inactive", "unknown"}:
        status = "active"
    cleaned["status"] = status
    cleaned["free"] = 1 if data.get("free") in (True, 1, "1", "true", "on") else 0
    cleaned["requires_account"] = 1 if data.get("requires_account") in (True, 1, "1", "true", "on") else 0
    return len(errors) == 0, cleaned, errors


def validate_category(data: dict):
    errors = []
    cleaned = {}
    name = sanitise_text(data.get("name", ""), 80)
    if not name:
        errors.append("Category name is required.")
    cleaned["name"] = name
    slug_raw = (data.get("slug") or "").strip()
    if not slug_raw:
        slug_raw = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    slug_valid, slug_err = validate_slug(slug_raw)
    if not slug_valid:
        errors.append(slug_err)
    cleaned["slug"] = slug_raw.strip().lower()
    cleaned["description"] = sanitise_text(data.get("description", ""), 300)
    parent_raw = data.get("parent_id")
    if parent_raw in (None, "", "0", 0):
        cleaned["parent_id"] = None
    else:
        try:
            cleaned["parent_id"] = int(parent_raw)
        except (TypeError, ValueError):
            errors.append("Invalid parent category.")
    icon = sanitise_text(data.get("icon", "folder"), 40)
    cleaned["icon"] = icon or "folder"
    try:
        cleaned["sort_order"] = int(data.get("sort_order", 0))
    except (TypeError, ValueError):
        cleaned["sort_order"] = 0
    return len(errors) == 0, cleaned, errors
