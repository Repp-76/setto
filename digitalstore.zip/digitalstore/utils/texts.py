"""
utils/texts.py
─────────────────────────────────────────────
Templat semua mesej yang dipaparkan oleh bot.

Pendekatan reka bentuk:
- Tanpa emoji.
- Gunakan simbol unicode (box-drawing, bullet) untuk kesan
  "premium / system" yang kemas.
- Pembentukan dipisahkan dari logik handler supaya senang
  diubah suai oleh pemilik bot pada bila-bila masa tanpa
  menyentuh fail handler.
"""

from datetime import datetime


DIVIDER = "━━━━━━━━━━━━━━━━━━━━"


def format_price(price: float) -> str:
    """
    Format harga kepada bentuk RM yang kemas.
    Contoh: 25.0 -> "RM 25", 19.5 -> "RM 19.50"
    """
    if price == int(price):
        return f"RM {int(price)}"
    return f"RM {price:.2f}"


def welcome_text(full_name: str, username: str | None, user_id: int) -> str:
    """Mesej selamat datang untuk /start."""
    uname = f"@{username}" if username else "Tidak ditetapkan"
    return (
        f"{DIVIDER}\n"
        f"「 DIGITAL STORE 」\n"
        f"{DIVIDER}\n\n"
        f"Selamat datang, {full_name}.\n\n"
        f"Sistem tempahan automatik ini membolehkan anda\n"
        f"membuat tempahan produk digital dengan pantas\n"
        f"dan selamat.\n\n"
        f"┆ Username  :  {uname}\n"
        f"┆ User ID   :  {user_id}\n\n"
        f"Sila pilih item yang tersedia di bawah.\n\n"
        f"{DIVIDER}"
    )


def no_items_text() -> str:
    """Mesej apabila belum ada item ditambah oleh admin."""
    return (
        f"{DIVIDER}\n"
        f"「 DIGITAL STORE 」\n"
        f"{DIVIDER}\n\n"
        f"Tiada item tersedia pada masa ini.\n\n"
        f"Sila semak semula tidak lama lagi.\n\n"
        f"{DIVIDER}"
    )


def item_button_label(name: str, price: float) -> str:
    """Label butang untuk setiap item di inline keyboard."""
    return f"{name}  ·  {format_price(price)}"


def ask_price_text(item_name: str) -> str:
    """Mesej kepada admin untuk meminta harga item baru."""
    return (
        f"{DIVIDER}\n"
        f"「 TAMBAH ITEM 」\n"
        f"{DIVIDER}\n\n"
        f"Item    :  {item_name}\n\n"
        f"Sila balas mesej ini dengan harga item\n"
        f"dalam bentuk nombor.\n\n"
        f"Contoh  :  25  atau  19.90\n\n"
        f"{DIVIDER}"
    )


def item_added_text(item_name: str, price: float) -> str:
    """Mesej kepada admin selepas item berjaya ditambah."""
    return (
        f"{DIVIDER}\n"
        f"「 ITEM DITAMBAH 」\n"
        f"{DIVIDER}\n\n"
        f"Item    :  {item_name}\n"
        f"Harga   :  {format_price(price)}\n\n"
        f"Item kini dipaparkan pada menu utama.\n\n"
        f"{DIVIDER}"
    )


def item_exists_text(item_name: str) -> str:
    """Mesej apabila admin cuba menambah item yang sudah wujud."""
    return (
        f"{DIVIDER}\n"
        f"「 RALAT 」\n"
        f"{DIVIDER}\n\n"
        f"Item \"{item_name}\" sudah wujud dalam senarai.\n\n"
        f"Sila gunakan nama lain.\n\n"
        f"{DIVIDER}"
    )


def invalid_price_text() -> str:
    """Mesej apabila admin masukkan harga tidak sah."""
    return (
        f"{DIVIDER}\n"
        f"「 RALAT 」\n"
        f"{DIVIDER}\n\n"
        f"Format harga tidak sah.\n\n"
        f"Sila masukkan nombor sahaja.\n"
        f"Contoh  :  25  atau  19.90\n\n"
        f"{DIVIDER}"
    )


def order_picked_text(item_name: str) -> str:
    """Mesej kepada pembeli serta-merta selepas menekan item."""
    return (
        f"{DIVIDER}\n"
        f"「 TEMPAHAN DITERIMA 」\n"
        f"{DIVIDER}\n\n"
        f"Item    :  {item_name}\n\n"
        f"Tempahan anda sedang diproses.\n"
        f"Sila tunggu maklumat pembayaran.\n\n"
        f"{DIVIDER}"
    )


def admin_new_order_text(item_name: str, full_name: str, username: str | None, user_id: int, order_id: int) -> str:
    """Notifikasi kepada admin apabila ada tempahan baru."""
    uname = f"@{username}" if username else "Tidak ditetapkan"
    return (
        f"{DIVIDER}\n"
        f"「 NEW ORDER 」\n"
        f"{DIVIDER}\n\n"
        f"┆ Order ID  :  #{order_id}\n"
        f"┆ Item      :  {item_name}\n"
        f"┆ Nama      :  {full_name}\n"
        f"┆ Username  :  {uname}\n"
        f"┆ User ID   :  {user_id}\n\n"
        f"{DIVIDER}"
    )


def payment_required_text(price: float) -> str:
    """Mesej meminta pembeli membuat pembayaran selepas QR dihantar."""
    return (
        f"{DIVIDER}\n"
        f"「 PAYMENT REQUIRED 」\n"
        f"{DIVIDER}\n\n"
        f"Jumlah  :  {format_price(price)}\n\n"
        f"Sila lakukan pembayaran mengikut QR Code\n"
        f"di atas, kemudian hantarkan bukti pembayaran\n"
        f"(gambar / dokumen / fail) di sini.\n\n"
        f"{DIVIDER}"
    )


def qr_caption_text(price: float) -> str:
    """Caption yang disertakan bersama imej / link QR Code."""
    return (
        f"{DIVIDER}\n"
        f"「 KOD QR PEMBAYARAN 」\n"
        f"{DIVIDER}\n\n"
        f"Jumlah  :  {format_price(price)}\n\n"
        f"Imbas kod QR di atas untuk membuat\n"
        f"pembayaran.\n\n"
        f"{DIVIDER}"
    )


def qr_link_fallback_text(price: float) -> str:
    """Mesej apabila bot hanya boleh hantar QR melalui link."""
    return (
        f"{DIVIDER}\n"
        f"「 KOD QR PEMBAYARAN 」\n"
        f"{DIVIDER}\n\n"
        f"Jumlah     :  {format_price(price)}\n\n"
        f"Sila imbas kod QR melalui pautan\n"
        f"di bawah untuk membuat pembayaran.\n\n"
        f"{DIVIDER}"
    )


def no_pending_order_text() -> str:
    """Mesej apabila pembeli hantar bukti tanpa ada order aktif."""
    return (
        f"{DIVIDER}\n"
        f"「 NOTIS 」\n"
        f"{DIVIDER}\n\n"
        f"Tiada tempahan aktif dikesan.\n\n"
        f"Sila pilih item terlebih dahulu melalui /start\n"
        f"sebelum menghantar bukti pembayaran.\n\n"
        f"{DIVIDER}"
    )


def proof_received_buyer_text() -> str:
    """Mesej kepada pembeli selepas bukti pembayaran diterima."""
    return (
        f"{DIVIDER}\n"
        f"「 BUKTI DITERIMA 」\n"
        f"{DIVIDER}\n\n"
        f"Bukti pembayaran anda telah diterima\n"
        f"dan kini menunggu pengesahan admin.\n\n"
        f"Sila tunggu sebentar.\n\n"
        f"{DIVIDER}"
    )


def admin_payment_received_text(item_name: str, full_name: str, username: str | None, user_id: int, order_id: int) -> str:
    """Notifikasi kepada admin apabila bukti pembayaran diterima."""
    uname = f"@{username}" if username else "Tidak ditetapkan"
    return (
        f"{DIVIDER}\n"
        f"「 PAYMENT RECEIVED 」\n"
        f"{DIVIDER}\n\n"
        f"┆ Order ID  :  #{order_id}\n"
        f"┆ Item      :  {item_name}\n"
        f"┆ Nama      :  {full_name}\n"
        f"┆ Username  :  {uname}\n"
        f"┆ User ID   :  {user_id}\n\n"
        f"Taip  /success {user_id}  untuk sahkan pembayaran.\n\n"
        f"{DIVIDER}"
    )


def payment_verified_buyer_text() -> str:
    """Mesej kepada pembeli selepas admin mengesahkan pembayaran."""
    return (
        f"{DIVIDER}\n"
        f"「 PAYMENT VERIFIED 」\n"
        f"{DIVIDER}\n\n"
        f"Pembayaran anda telah berjaya disahkan.\n\n"
        f"Sila tunggu penghantaran produk anda.\n\n"
        f"{DIVIDER}"
    )


def success_admin_confirm_text(order_id: int, item_name: str, user_id: int) -> str:
    """Mesej kepada admin selepas /success berjaya."""
    return (
        f"{DIVIDER}\n"
        f"「 STATUS DIKEMASKINI 」\n"
        f"{DIVIDER}\n\n"
        f"Order ID  :  #{order_id}\n"
        f"Item      :  {item_name}\n"
        f"User ID   :  {user_id}\n"
        f"Status    :  Paid\n\n"
        f"Pembeli telah dimaklumkan.\n"
        f"Gunakan /send {user_id} untuk hantar produk.\n\n"
        f"{DIVIDER}"
    )


def success_no_order_text() -> str:
    """Mesej kepada admin jika tiada order ditemui untuk /success."""
    return (
        f"{DIVIDER}\n"
        f"「 RALAT 」\n"
        f"{DIVIDER}\n\n"
        f"Tiada tempahan ditemui untuk\n"
        f"pengguna tersebut.\n\n"
        f"{DIVIDER}"
    )


def usage_success_text() -> str:
    """Mesej arahan penggunaan /success."""
    return (
        f"{DIVIDER}\n"
        f"「 CARA PENGGUNAAN 」\n"
        f"{DIVIDER}\n\n"
        f"/success {{user_id}}\n\n"
        f"Contoh  :  /success 123456789\n\n"
        f"{DIVIDER}"
    )


def usage_send_text() -> str:
    """Mesej arahan penggunaan /send."""
    return (
        f"{DIVIDER}\n"
        f"「 CARA PENGGUNAAN 」\n"
        f"{DIVIDER}\n\n"
        f"1. Hantar media / teks yang ingin dihantar.\n"
        f"2. Reply mesej tersebut dengan:\n\n"
        f"   /send {{user_id}}\n\n"
        f"Contoh  :  /send 123456789\n\n"
        f"{DIVIDER}"
    )


def usage_add_text() -> str:
    """Mesej arahan penggunaan /add."""
    return (
        f"{DIVIDER}\n"
        f"「 CARA PENGGUNAAN 」\n"
        f"{DIVIDER}\n\n"
        f"/add {{nama item}}\n\n"
        f"Contoh  :  /add Panel Unlimited\n\n"
        f"{DIVIDER}"
    )


def reply_required_text() -> str:
    """Mesej apabila admin guna /send tanpa reply."""
    return (
        f"{DIVIDER}\n"
        f"「 RALAT 」\n"
        f"{DIVIDER}\n\n"
        f"Sila reply mesej yang ingin dihantar\n"
        f"dengan arahan /send {{user_id}}.\n\n"
        f"{DIVIDER}"
    )


def send_success_admin_text(order_id_or_user: int) -> str:
    """Mesej kepada admin selepas /send berjaya."""
    return (
        f"{DIVIDER}\n"
        f"「 PRODUK DIHANTAR 」\n"
        f"{DIVIDER}\n\n"
        f"Kandungan berjaya dihantar kepada\n"
        f"User ID  :  {order_id_or_user}\n\n"
        f"{DIVIDER}"
    )


def send_failed_admin_text(user_id: int) -> str:
    """Mesej kepada admin jika /send gagal (cth: bot diblok)."""
    return (
        f"{DIVIDER}\n"
        f"「 RALAT 」\n"
        f"{DIVIDER}\n\n"
        f"Gagal menghantar kandungan kepada\n"
        f"User ID  :  {user_id}\n\n"
        f"Pengguna mungkin telah menyekat bot.\n\n"
        f"{DIVIDER}"
    )


def invalid_user_id_text() -> str:
    """Mesej apabila format User ID tidak sah."""
    return (
        f"{DIVIDER}\n"
        f"「 RALAT 」\n"
        f"{DIVIDER}\n\n"
        f"Format User ID tidak sah.\n\n"
        f"Sila masukkan nombor sahaja.\n\n"
        f"{DIVIDER}"
    )


def not_admin_text() -> str:
    """Mesej apabila pengguna biasa cuba guna arahan admin."""
    return (
        f"{DIVIDER}\n"
        f"「 AKSES DITOLAK 」\n"
        f"{DIVIDER}\n\n"
        f"Arahan ini hanya untuk admin.\n\n"
        f"{DIVIDER}"
    )
