"""
utils/__init__.py
─────────────────────────────────────────────
Pakej utiliti — mengandungi templat teks, keyboard,
dan FSM states.
"""
