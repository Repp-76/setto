"""
database.py
─────────────────────────────────────────────
Modul pengurusan pangkalan data (SQLite).

Tanggungjawab modul ini:
- Membina struktur jadual (items, orders).
- Menyediakan fungsi CRUD untuk item dan order.
- Semua operasi DB dijalankan secara async (aiosqlite)
  supaya tidak menyekat (block) event loop bot — ini penting
  untuk memastikan respon bot kekal pantas tanpa delay.
"""

import logging
from datetime import datetime
from typing import Optional

import aiosqlite

from config import DB_PATH

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# SQL SCHEMA
# ─────────────────────────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    price REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT,
    item_name TEXT NOT NULL,
    price REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT NOT NULL
);
"""


async def init_db() -> None:
    """
    Mencipta jadual database jika belum wujud.
    Dipanggil sekali sahaja semasa bot mula dijalankan.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA)
        await db.commit()
    logger.info("Database berjaya diinisialisasi (%s)", DB_PATH)


# ─────────────────────────────────────────────
# OPERASI ITEM
# ─────────────────────────────────────────────
async def add_item(name: str, price: float) -> bool:
    """
    Menambah item baru ke dalam database.

    Returns:
        True jika berjaya, False jika nama item sudah wujud.
    """
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO items (name, price, created_at) VALUES (?, ?, ?)",
                (name, price, datetime.now().isoformat()),
            )
            await db.commit()
        logger.info("Item ditambah: %s (RM%.2f)", name, price)
        return True
    except aiosqlite.IntegrityError:
        logger.warning("Percubaan menambah item yang sudah wujud: %s", name)
        return False


async def get_all_items() -> list[dict]:
    """
    Mendapatkan semua item yang tersedia, disusun mengikut
    masa ditambah (paling lama dahulu) supaya kedudukan butang
    di menu /start kekal konsisten.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, name, price FROM items ORDER BY id ASC"
        ) as cursor:
            rows = await cursor.fetchall()
            return [dict(row) for row in rows]


async def get_item_by_id(item_id: int) -> Optional[dict]:
    """Mendapatkan satu item berdasarkan ID."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT id, name, price FROM items WHERE id = ?", (item_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


# ─────────────────────────────────────────────
# OPERASI ORDER
# ─────────────────────────────────────────────
async def create_order(
    user_id: int, username: Optional[str], item_name: str, price: float
) -> int:
    """
    Mencipta order baru dengan status 'Pending'.

    Returns:
        order_id (int) bagi order yang baru dicipta.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            """
            INSERT INTO orders (user_id, username, item_name, price, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                username,
                item_name,
                price,
                "Pending",
                datetime.now().isoformat(),
            ),
        )
        await db.commit()
        order_id = cursor.lastrowid
    logger.info("Order baru dicipta: #%s oleh user %s (%s)", order_id, user_id, item_name)
    return order_id


async def get_latest_pending_order(user_id: int) -> Optional[dict]:
    """
    Mendapatkan order terbaru milik pengguna yang masih berstatus
    'Pending' atau 'Proof Sent'. Digunakan untuk mengesan order
    semasa apabila pembeli menghantar bukti pembayaran.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """
            SELECT * FROM orders
            WHERE user_id = ? AND status IN ('Pending', 'Proof Sent')
            ORDER BY order_id DESC LIMIT 1
            """,
            (user_id,),
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def get_order_by_id(order_id: int) -> Optional[dict]:
    """Mendapatkan order berdasarkan order_id."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM orders WHERE order_id = ?", (order_id,)
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def get_latest_order_for_user(user_id: int) -> Optional[dict]:
    """
    Mendapatkan order PALING BARU bagi seorang pengguna,
    tanpa mengira status. Digunakan oleh /success untuk
    menentukan order mana yang hendak disahkan.
    """
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM orders WHERE user_id = ? ORDER BY order_id DESC LIMIT 1",
            (user_id,),
        ) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def update_order_status(order_id: int, status: str) -> None:
    """Mengemas kini status order (Pending / Proof Sent / Paid)."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "UPDATE orders SET status = ? WHERE order_id = ?", (status, order_id)
        )
        await db.commit()
    logger.info("Order #%s dikemaskini ke status: %s", order_id, status)
