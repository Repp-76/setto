Letakkan fail QR Code anda di sini dengan nama:

    qrcode.png

Bot akan cuba hantar fail ini dahulu. Jika fail tidak
wujud atau gagal dihantar, bot akan beralih secara
automatik kepada QR_CODE_URL yang ditetapkan dalam
config.py.

Format yang disokong: PNG (disyorkan), JPG.
