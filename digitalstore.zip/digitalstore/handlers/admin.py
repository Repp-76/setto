"""
handlers/admin.py
─────────────────────────────────────────────
Handler untuk semua arahan ADMIN:

- /add {nama item}      : Menambah item baru (FSM 2-langkah: nama -> harga)
- /success {user_id}    : Mengesahkan pembayaran pembeli
- /send {user_id}       : Menghantar produk/media kepada pembeli (reply)

Semua handler di sini dilindungi oleh AdminFilter — hanya
ID dalam config.ADMIN_IDS boleh menggunakannya.
"""

import logging

from aiogram import Bot, Router
from aiogram.filters import BaseFilter, Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

import database as db
from config import ADMIN_IDS
from utils import texts
from utils.states import AddItemStates

logger = logging.getLogger(__name__)

router = Router(name="admin")


# ─────────────────────────────────────────────
# Filter: hanya admin
# ─────────────────────────────────────────────
class IsAdmin(BaseFilter):
    """Filter yang hanya membenarkan ID dalam ADMIN_IDS."""

    async def __call__(self, message: Message) -> bool:
        return message.from_user.id in ADMIN_IDS


router.message.filter(IsAdmin())


# ─────────────────────────────────────────────
# /add {nama item}  ->  Langkah 1: terima nama item
# ─────────────────────────────────────────────
@router.message(Command("add"))
async def cmd_add_item(message: Message, command: CommandObject, state: FSMContext) -> None:
    """
    Langkah pertama menambah item.

    Format  :  /add {nama item}

    Selepas nama item diterima, bot akan meminta admin
    membalas dengan harga (langkah seterusnya dikendalikan
    oleh `receive_item_price`).
    """
    item_name = (command.args or "").strip()

    if not item_name:
        await message.answer(texts.usage_add_text())
        return

    # Simpan nama item di dalam FSM context, tunggu harga.
    await state.update_data(pending_item_name=item_name)
    await state.set_state(AddItemStates.waiting_for_price)

    await message.answer(texts.ask_price_text(item_name))

    logger.info("Admin %s memulakan proses tambah item: %s", message.from_user.id, item_name)


# ─────────────────────────────────────────────
# /add {nama item}  ->  Langkah 2: terima harga
# ─────────────────────────────────────────────
@router.message(AddItemStates.waiting_for_price)
async def receive_item_price(message: Message, state: FSMContext) -> None:
    """
    Langkah kedua: admin membalas dengan harga item.

    - Validasi input mestilah nombor (int/float).
    - Simpan item ke database.
    - Padam state selepas selesai.
    """
    raw_price = (message.text or "").strip().replace(",", ".")

    try:
        price = float(raw_price)
        if price < 0:
            raise ValueError("Harga tidak boleh negatif")
    except ValueError:
        await message.answer(texts.invalid_price_text())
        return

    data = await state.get_data()
    item_name = data.get("pending_item_name")

    if not item_name:
        # Selamat-gagal: jika data hilang atas sebab tertentu.
        await state.clear()
        await message.answer(texts.usage_add_text())
        return

    success = await db.add_item(item_name, price)
    await state.clear()

    if success:
        await message.answer(texts.item_added_text(item_name, price))
    else:
        await message.answer(texts.item_exists_text(item_name))


# ─────────────────────────────────────────────
# /success {user_id}
# ─────────────────────────────────────────────
@router.message(Command("success"))
async def cmd_success(message: Message, command: CommandObject, bot: Bot) -> None:
    """
    Mengesahkan pembayaran pembeli.

    Format  :  /success {user_id}

    1. Cari order terbaru milik user_id tersebut.
    2. Tukar status order kepada "Paid".
    3. Hantar mesej "PAYMENT VERIFIED" kepada pembeli.
    4. Sahkan kepada admin.
    """
    args = (command.args or "").strip()

    if not args:
        await message.answer(texts.usage_success_text())
        return

    try:
        target_user_id = int(args)
    except ValueError:
        await message.answer(texts.invalid_user_id_text())
        return

    order = await db.get_latest_order_for_user(target_user_id)

    if not order:
        await message.answer(texts.success_no_order_text())
        return

    await db.update_order_status(order["order_id"], "Paid")

    # Maklumkan pembeli
    try:
        await bot.send_message(target_user_id, texts.payment_verified_buyer_text())
    except Exception:
        logger.exception("Gagal hantar PAYMENT VERIFIED kepada user %s", target_user_id)

    # Sahkan kepada admin
    await message.answer(
        texts.success_admin_confirm_text(order["order_id"], order["item_name"], target_user_id)
    )

    logger.info(
        "Order #%s disahkan PAID oleh admin %s (pembeli: %s)",
        order["order_id"], message.from_user.id, target_user_id,
    )


# ─────────────────────────────────────────────
# /send {user_id}  (mesti reply pada media/teks)
# ─────────────────────────────────────────────
@router.message(Command("send"))
async def cmd_send(message: Message, command: CommandObject, bot: Bot) -> None:
    """
    Menghantar kandungan (apa-apa jenis media Telegram) kepada
    pembeli yang ditentukan.

    Cara guna:
        1. Admin hantar media/teks yang ingin dihantar.
        2. Admin reply media tersebut dengan: /send {user_id}

    Bot menyalin (copy) mesej yang di-reply terus kepada
    pembeli — menyokong semua jenis media (text, photo, video,
    audio, document, sticker, dan lain-lain) kerana method
    `copy_message` mengendalikan semua jenis kandungan secara
    automatik tanpa perlu logik berasingan untuk setiap jenis.
    """
    args = (command.args or "").strip()

    if not args:
        await message.answer(texts.usage_send_text())
        return

    try:
        target_user_id = int(args)
    except ValueError:
        await message.answer(texts.invalid_user_id_text())
        return

    if not message.reply_to_message:
        await message.answer(texts.reply_required_text())
        return

    try:
        await message.reply_to_message.copy_to(chat_id=target_user_id)
        await message.answer(texts.send_success_admin_text(target_user_id))
        logger.info(
            "Admin %s menghantar kandungan kepada user %s",
            message.from_user.id, target_user_id,
        )
    except Exception:
        logger.exception("Gagal /send kepada user %s", target_user_id)
        await message.answer(texts.send_failed_admin_text(target_user_id))
