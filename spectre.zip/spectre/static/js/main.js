/**
 * SPECTRE OSINT Platform — Main Frontend
 * =========================================
 * Handles: tree navigation, category/resource rendering,
 *          real-time search, usage tracking, and UI state.
 *
 * Architecture: vanilla JS module pattern — no framework dependency.
 */

"use strict";

// ── Icon map (Feather-style SVG paths keyed by name) ─────────────────────────
const ICONS = {
  "folder":        '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
  "user":          '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  "network":       '<rect x="2" y="2" width="6" height="6"/><rect x="16" y="2" width="6" height="6"/><rect x="9" y="16" width="6" height="6"/><line x1="5" y1="8" x2="5" y2="19"/><line x1="19" y1="8" x2="19" y2="19"/><line x1="5" y1="19" x2="9" y2="19"/><line x1="15" y1="19" x2="19" y2="19"/>',
  "share":         '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',
  "shield":        '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  "map-pin":       '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
  "briefcase":     '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
  "archive":       '<polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/>',
  "landmark":      '<line x1="3" y1="22" x2="21" y2="22"/><line x1="6" y1="18" x2="6" y2="11"/><line x1="10" y1="18" x2="10" y2="11"/><line x1="14" y1="18" x2="14" y2="11"/><line x1="18" y1="18" x2="18" y2="11"/><polygon points="12 2 20 7 4 7"/>',
  "search":        '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  "eye-off":       '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>',
  "at-sign":       '<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"/>',
  "mail":          '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
  "phone":         '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 11 19.79 19.79 0 0 1 1.61 2.38a2 2 0 0 1 1.99-2.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 6.5a16 16 0 0 0 6 6l.44-.44a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21 14z"/>',
  "users":         '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  "server":        '<rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>',
  "git-branch":    '<line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  "file-text":     '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>',
  "lock":          '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  "activity":      '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
  "bar-chart-2":   '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  "bug":           '<circle cx="8" cy="9" r="2"/><circle cx="16" cy="9" r="2"/><path d="M9 9h6v10a4 4 0 0 1-4 4v0a4 4 0 0 1-4-4V9h2"/><path d="M7.4 6A5.92 5.92 0 0 1 12 4a5.92 5.92 0 0 1 4.6 2"/><line x1="2" y1="15" x2="7" y2="15"/><line x1="17" y1="15" x2="22" y2="15"/><line x1="2" y1="9" x2="4.5" y2="9"/><line x1="19.5" y1="9" x2="22" y2="9"/>',
  "alert-triangle":'<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  "link":          '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  "crosshair":     '<circle cx="12" cy="12" r="10"/><line x1="22" y1="12" x2="18" y2="12"/><line x1="6" y1="12" x2="2" y2="12"/><line x1="12" y1="6" x2="12" y2="2"/><line x1="12" y1="22" x2="12" y2="18"/>',
  "send":          '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  "anchor":        '<circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/>',
  "globe":         '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  "building":      '<rect x="1" y="3" width="15" height="18"/><path d="M16 8h4l3 3v10h-7V8z"/><line x1="5" y1="8" x2="5" y2="8"/><line x1="10" y1="8" x2="10" y2="8"/><line x1="5" y1="12" x2="5" y2="12"/><line x1="10" y1="12" x2="10" y2="12"/><line x1="5" y1="16" x2="5" y2="16"/><line x1="10" y1="16" x2="10" y2="16"/>',
  "dollar-sign":   '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
  "truck":         '<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
  "image":         '<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
  "layers":        '<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  "file":          '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/>',
  "clock":         '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  "scale":         '<line x1="12" y1="2" x2="12" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/><line x1="2" y1="8" x2="22" y2="8"/><line x1="4" y1="12" x2="20" y2="12"/>',
  "terminal":      '<polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>',
  "external-link": '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
  "chevron-right": '<polyline points="9 18 15 12 9 6"/>',
  "home":          '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  "settings":      '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  "download":      '<polyline points="8 17 12 21 16 17"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"/>',
  "upload":        '<polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>',
};

function icon(name, size = 16) {
  const path = ICONS[name] || ICONS["folder"];
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24"
    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
    stroke-linejoin="round">${path}</svg>`;
}

// ── State ─────────────────────────────────────────────────────────────────────
const state = {
  tree: [],           // Full category tree from API
  activeNodeId: null, // Currently selected category id
  searchTimer: null,  // Debounce handle
  searchMode: false,  // True when showing search results
};

// ── DOM refs ──────────────────────────────────────────────────────────────────
const $tree       = document.getElementById("tree-nav");
const $content    = document.getElementById("main-content");
const $searchInput= document.getElementById("global-search");
const $toast      = document.getElementById("toast");

// ── Toast notification ────────────────────────────────────────────────────────
function showToast(msg, duration = 2500) {
  $toast.querySelector(".toast-msg").textContent = msg;
  $toast.classList.add("show");
  clearTimeout($toast._timer);
  $toast._timer = setTimeout(() => $toast.classList.remove("show"), duration);
}

// ── SVG icon helper in HTML ────────────────────────────────────────────────────
function iconHtml(name, size = 16) { return icon(name, size); }

// ── API helpers ───────────────────────────────────────────────────────────────
async function apiFetch(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

// ── Build tree DOM ────────────────────────────────────────────────────────────
function buildTree(nodes, depth = 0) {
  const ul = document.createElement("ul");
  ul.className = "tree";
  if (depth > 0) {
    ul.className = "tree-children";
  }

  nodes.forEach(node => {
    const li   = document.createElement("li");
    li.className = "tree-node";

    const hasChildren = node.children && node.children.length > 0;

    const item = document.createElement("div");
    item.className = "tree-item";
    item.dataset.id = node.id;
    item.style.paddingLeft = `${10 + depth * 14}px`;

    // Toggle arrow
    const toggleEl = document.createElement("span");
    toggleEl.className = "tree-toggle";
    toggleEl.innerHTML = hasChildren
      ? iconHtml("chevron-right", 12)
      : '<span style="display:inline-block;width:12px"></span>';

    // Category icon
    const iconEl = document.createElement("span");
    iconEl.className = "tree-icon";
    iconEl.innerHTML = iconHtml(node.icon || "folder", 14);

    // Name
    const nameEl = document.createElement("span");
    nameEl.className = "tree-item-name";
    nameEl.textContent = node.name;

    // Count badge
    const countEl = document.createElement("span");
    countEl.className = "tree-count";
    const totalCount = countResources(node);
    countEl.textContent = totalCount;

    item.append(toggleEl, iconEl, nameEl, countEl);

    // Children container
    let childrenUl = null;
    if (hasChildren) {
      childrenUl = buildTree(node.children, depth + 1);
      li.append(item, childrenUl);
    } else {
      li.append(item);
    }

    // Click handler
    item.addEventListener("click", (e) => {
      e.stopPropagation();

      // Toggle expand if has children
      if (hasChildren && e.target.closest(".tree-toggle")) {
        const isOpen = childrenUl.classList.toggle("open");
        toggleEl.classList.toggle("open", isOpen);
        return;
      }

      // Select node — load resources
      setActiveNode(node.id);
      loadCategory(node.id);

      // Auto-expand on click
      if (hasChildren && childrenUl) {
        childrenUl.classList.add("open");
        toggleEl.classList.add("open");
      }
    });

    ul.append(li);
  });

  return ul;
}

function countResources(node) {
  let count = node.resource_count || 0;
  if (node.children) {
    node.children.forEach(c => count += countResources(c));
  }
  return count;
}

// ── Mark active node in tree ───────────────────────────────────────────────────
function setActiveNode(id) {
  document.querySelectorAll(".tree-item.active").forEach(el => el.classList.remove("active"));
  const target = document.querySelector(`.tree-item[data-id="${id}"]`);
  if (target) {
    target.classList.add("active");
    // Reveal parents
    let parent = target.closest(".tree-children");
    while (parent) {
      parent.classList.add("open");
      const parentToggle = parent.previousElementSibling?.querySelector(".tree-toggle");
      if (parentToggle) parentToggle.classList.add("open");
      parent = parent.parentElement?.closest(".tree-children");
    }
  }
  state.activeNodeId = id;
}

// ── Load and render a category ────────────────────────────────────────────────
async function loadCategory(id) {
  state.searchMode = false;
  $content.innerHTML = `<div class="loading-state"><div class="spinner"></div><span>Fetching intelligence data…</span></div>`;

  try {
    const data = await apiFetch(`/api/categories/${id}`);
    renderCategory(data);
  } catch (err) {
    $content.innerHTML = `<div class="empty-state">
      ${iconHtml("alert-triangle", 48)}
      <p class="empty-state-title">Fetch Error</p>
      <p class="empty-state-sub">Could not load category data. Check console for details.</p>
    </div>`;
    console.error("loadCategory error:", err);
  }
}

function renderCategory(cat) {
  const resources = cat.resources || [];

  const cardsHtml = resources.length === 0
    ? `<div class="empty-state">
        ${iconHtml("folder", 48)}
        <p class="empty-state-title">No resources in this category</p>
        <p class="empty-state-sub">Add resources via the admin panel.</p>
       </div>`
    : `<div class="resource-grid">${resources.map(renderResourceCard).join("")}</div>`;

  $content.innerHTML = `
    <div class="resource-panel">
      <div class="panel-header">
        <div class="panel-icon-wrap">${iconHtml(cat.icon || "folder", 22)}</div>
        <div class="panel-meta">
          <div class="panel-cat-name">${esc(cat.name)}</div>
          ${cat.description ? `<div class="panel-cat-desc">${esc(cat.description)}</div>` : ""}
          <div class="panel-resource-count">${resources.length} resource${resources.length !== 1 ? "s" : ""}</div>
        </div>
      </div>
      ${cardsHtml}
    </div>`;

  // Attach visit button handlers
  $content.querySelectorAll(".visit-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const resId  = btn.dataset.id;
      const resUrl = btn.dataset.url;
      trackAndOpen(resId, resUrl);
    });
  });
}

function renderResourceCard(r) {
  const tags = (r.tags || []).map(t => `<span class="tag">${esc(t)}</span>`).join("");
  const freeBadge = r.free
    ? '<span class="badge badge-free">FREE</span>'
    : '<span class="badge badge-paid">PAID</span>';
  const accountBadge = r.requires_account
    ? '<span class="badge badge-account">ACCOUNT</span>'
    : "";

  return `
    <div class="resource-card">
      <div class="resource-card-name">${iconHtml("external-link", 13)} ${esc(r.name)}</div>
      ${r.description ? `<div class="resource-card-desc">${esc(r.description)}</div>` : ""}
      ${tags ? `<div class="resource-tags">${tags}</div>` : ""}
      <div class="resource-card-footer">
        ${freeBadge} ${accountBadge}
        <button class="visit-btn" data-id="${r.id}" data-url="${esc(r.url)}">
          ${iconHtml("external-link", 12)} Open
        </button>
      </div>
    </div>`;
}

// ── Usage tracking ────────────────────────────────────────────────────────────
function trackAndOpen(resourceId, url) {
  // Fire-and-forget tracking
  fetch(`/track/${resourceId}`, { method: "POST" }).catch(() => {});
  window.open(url, "_blank", "noopener,noreferrer");
}

// ── Search ────────────────────────────────────────────────────────────────────
function initSearch() {
  if (!$searchInput) return;

  $searchInput.addEventListener("input", () => {
    clearTimeout(state.searchTimer);
    const q = $searchInput.value.trim();

    if (q.length < 2) {
      if (state.searchMode) {
        state.searchMode = false;
        renderDashboard();
      }
      return;
    }

    state.searchTimer = setTimeout(() => performSearch(q), 280);
  });

  $searchInput.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      $searchInput.value = "";
      state.searchMode = false;
      renderDashboard();
    }
  });
}

async function performSearch(q) {
  state.searchMode = true;
  $content.innerHTML = `<div class="loading-state"><div class="spinner"></div><span>Scanning…</span></div>`;

  try {
    const data = await apiFetch(`/api/search?q=${encodeURIComponent(q)}`);
    renderSearchResults(q, data);
  } catch (err) {
    console.error("Search error:", err);
  }
}

function renderSearchResults(q, data) {
  const cats      = data.categories || [];
  const resources = data.resources  || [];
  const total     = cats.length + resources.length;

  if (total === 0) {
    $content.innerHTML = `<div class="search-results">
      <div class="search-hits-label">No results for <strong>"${esc(q)}"</strong></div>
      <div class="empty-state">
        ${iconHtml("search", 48)}
        <p class="empty-state-title">No matches found</p>
        <p class="empty-state-sub">Try a different keyword or browse the category tree.</p>
      </div>
    </div>`;
    return;
  }

  let html = `<div class="search-results">
    <div class="search-hits-label"><strong>${total}</strong> results for "<strong>${esc(q)}</strong>"</div>`;

  if (cats.length > 0) {
    html += `<div class="result-group-title">Categories (${cats.length})</div>`;
    html += `<div class="category-grid">`;
    html += cats.map(c => `
      <div class="cat-tile" data-cat-id="${c.id}">
        <div class="cat-tile-icon">${iconHtml(c.icon || "folder", 18)}</div>
        <div class="cat-tile-name">${esc(c.name)}</div>
        <div class="cat-tile-count">${esc(c.description || "")}</div>
      </div>`).join("");
    html += `</div>`;
  }

  if (resources.length > 0) {
    html += `<div class="result-group-title">Resources (${resources.length})</div>`;
    html += `<div class="resource-grid">`;
    html += resources.map(renderResourceCard).join("");
    html += `</div>`;
  }

  html += `</div>`;
  $content.innerHTML = html;

  // Cat tile click
  $content.querySelectorAll(".cat-tile[data-cat-id]").forEach(tile => {
    tile.addEventListener("click", () => {
      const id = parseInt(tile.dataset.catId);
      setActiveNode(id);
      loadCategory(id);
      $searchInput.value = "";
      state.searchMode = false;
    });
  });

  // Visit buttons
  $content.querySelectorAll(".visit-btn").forEach(btn => {
    btn.addEventListener("click", () => trackAndOpen(btn.dataset.id, btn.dataset.url));
  });
}

// ── Dashboard render ──────────────────────────────────────────────────────────
function renderDashboard() {
  // Restore the server-rendered home content
  const cached = document.getElementById("home-cache");
  if (cached) {
    $content.innerHTML = cached.innerHTML;
    bindDashboardEvents();
  }
}

function bindDashboardEvents() {
  // Category tiles on dashboard → load that category
  $content.querySelectorAll(".cat-tile[data-cat-id]").forEach(tile => {
    tile.addEventListener("click", () => {
      const id = parseInt(tile.dataset.catId);
      setActiveNode(id);
      loadCategory(id);
    });
  });

  // Recent items
  $content.querySelectorAll(".recent-item[data-url]").forEach(item => {
    item.addEventListener("click", () => {
      const url = item.dataset.url;
      const id  = item.dataset.id;
      if (url) trackAndOpen(id, url);
    });
  });
}

// ── Export button ─────────────────────────────────────────────────────────────
function initExport() {
  const btn = document.getElementById("btn-export");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    try {
      const data = await apiFetch("/api/export");
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href = url;
      a.download = `spectre-export-${new Date().toISOString().slice(0,10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast("Export complete.");
    } catch (err) {
      showToast("Export failed. See console.");
      console.error(err);
    }
  });
}

// ── Sidebar toggle (mobile) ───────────────────────────────────────────────────
function initSidebarToggle() {
  const btn = document.getElementById("btn-sidebar-toggle");
  const sidebar = document.getElementById("sidebar");
  if (!btn || !sidebar) return;
  btn.addEventListener("click", () => {
    sidebar.classList.toggle("mobile-open");
  });
}

// ── Home button ───────────────────────────────────────────────────────────────
function initHomeBtn() {
  const btn = document.getElementById("btn-home");
  if (!btn) return;
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tree-item.active").forEach(el => el.classList.remove("active"));
    state.activeNodeId = null;
    if ($searchInput) $searchInput.value = "";
    state.searchMode = false;
    renderDashboard();
  });
}

// ── Escape HTML ───────────────────────────────────────────────────────────────
function esc(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ── Boot ──────────────────────────────────────────────────────────────────────
async function init() {
  try {
    state.tree = await apiFetch("/api/tree");
    const treeEl = buildTree(state.tree);
    $tree.appendChild(treeEl);
  } catch (err) {
    console.error("Tree load failed:", err);
    $tree.innerHTML = `<p class="text-dim" style="padding:12px;font-size:12px;">Failed to load categories.</p>`;
  }

  initSearch();
  initExport();
  initSidebarToggle();
  initHomeBtn();
  bindDashboardEvents();
}

document.addEventListener("DOMContentLoaded", init);
