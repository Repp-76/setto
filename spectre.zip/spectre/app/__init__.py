"""
app/__init__.py
---------------
Application factory for SPECTRE OSINT Platform.
Creates TWO separate Flask apps:
  - public_app  → serves portal only (no admin routes)
  - admin_app   → serves admin panel only, IP-restricted
"""

import os
import logging
from logging.handlers import RotatingFileHandler
from flask import Flask, g, request, abort
from .database import init_db, get_db


# ── Shared config ──────────────────────────────────────────────────────────────

def _base_config(app):
    app.config["SECRET_KEY"] = os.environ.get(
        "SECRET_KEY", "CHANGE_THIS_IN_PRODUCTION_" + os.urandom(16).hex()
    )
    app.config["DATABASE"] = os.path.join(
        os.path.dirname(os.path.dirname(__file__)), "data", "spectre.db"
    )
    app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024


def _setup_logging(app, logfile="spectre.log"):
    logs_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
    os.makedirs(logs_dir, exist_ok=True)
    handler = RotatingFileHandler(
        os.path.join(logs_dir, logfile), maxBytes=1_000_000, backupCount=5
    )
    handler.setFormatter(logging.Formatter(
        "[%(asctime)s] %(levelname)s in %(module)s: %(message)s"
    ))
    app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)


def _security_headers(app):
    @app.after_request
    def _headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"]         = "DENY"
        response.headers["X-XSS-Protection"]        = "1; mode=block"
        response.headers["Referrer-Policy"]          = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"]  = (
            "default-src 'self'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "script-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; "
            "connect-src 'self';"
        )
        return response


def _db_teardown(app):
    @app.teardown_appcontext
    def close_db(error):
        db = g.pop("db", None)
        if db is not None:
            db.close()


# ── IP allowlist for admin ─────────────────────────────────────────────────────

# Read allowed IPs from env or use defaults.
# Set ADMIN_ALLOWED_IPS="192.168.1.10,10.0.0.5" to customise.
# "127.0.0.1" and "::1" (localhost) are always allowed.
_DEFAULT_ADMIN_IPS = {"127.0.0.1", "::1", "localhost"}


def _get_admin_allowed_ips():
    env_ips = os.environ.get("ADMIN_ALLOWED_IPS", "")
    extra   = {ip.strip() for ip in env_ips.split(",") if ip.strip()}
    return _DEFAULT_ADMIN_IPS | extra


def _admin_ip_guard(app):
    """Block requests whose remote IP is not in the allowlist."""
    allowed = _get_admin_allowed_ips()

    @app.before_request
    def _check_ip():
        # Support X-Forwarded-For if behind a trusted proxy
        forwarded = request.headers.get("X-Forwarded-For", "")
        client_ip = forwarded.split(",")[0].strip() if forwarded else request.remote_addr

        if client_ip not in allowed:
            app.logger.warning(
                f"Admin access DENIED for IP {client_ip} → {request.path}"
            )
            abort(403)


# ── Public app factory ────────────────────────────────────────────────────────

def create_public_app():
    """
    Public portal — serves the OSINT portal and read-only API.
    Runs on 0.0.0.0:8980. No admin routes.
    """
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
    _base_config(app)
    _setup_logging(app, "public.log")

    with app.app_context():
        init_db(app)

    _db_teardown(app)
    _security_headers(app)

    from .routes.main import main_bp
    from .routes.api  import api_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp, url_prefix="/api")

    app.logger.info("SPECTRE public portal initialised.")
    return app


# ── Admin app factory ─────────────────────────────────────────────────────────

def create_admin_app():
    """
    Admin panel — IP-restricted, serves only the admin dashboard.
    Runs on 0.0.0.0:8089. Only configured IPs can connect.
    """
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
    _base_config(app)
    _setup_logging(app, "admin.log")

    with app.app_context():
        init_db(app)

    _db_teardown(app)
    _security_headers(app)
    _admin_ip_guard(app)

    from .routes.admin import admin_bp
    from .routes.api   import api_bp   # Admin also needs API for export

    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(api_bp,   url_prefix="/api")

    # Redirect root to /admin/
    from flask import redirect, url_for

    @app.route("/")
    def admin_root():
        return redirect("/admin/")

    app.logger.info("SPECTRE admin panel initialised.")
    return app


# ── Legacy single-app factory (kept for test compatibility) ──────────────────

def create_app():
    """Single-app mode — used by unit tests only."""
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
    _base_config(app)
    _setup_logging(app)

    with app.app_context():
        init_db(app)

    _db_teardown(app)
    _security_headers(app)

    from .routes.main  import main_bp
    from .routes.api   import api_bp
    from .routes.admin import admin_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(api_bp,   url_prefix="/api")
    app.register_blueprint(admin_bp, url_prefix="/admin")

    app.logger.info("SPECTRE single-app mode initialised.")
    return app
