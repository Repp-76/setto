"""
utils/keyboards.py
─────────────────────────────────────────────
Pembina (builder) untuk semua Inline Keyboard yang
digunakan oleh bot.

Memisahkan logik keyboard daripada handler menjadikan
kod lebih kemas dan mudah diubah suai pada masa hadapan
(contohnya menambah butang baru tanpa menyentuh fail
handler utama).
"""

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from utils.texts import item_button_label


def build_items_keyboard(items: list[dict]) -> InlineKeyboardMarkup | None:
    """
    Membina inline keyboard untuk senarai item.

    Setiap butang mempunyai callback_data dalam format:
        item:{item_id}

    Returns:
        InlineKeyboardMarkup jika ada item, None jika senarai kosong.
    """
    if not items:
        return None

    rows = []
    for item in items:
        label = item_button_label(item["name"], item["price"])
        rows.append(
            [InlineKeyboardButton(text=label, callback_data=f"item:{item['id']}")]
        )

    return InlineKeyboardMarkup(inline_keyboard=rows)
