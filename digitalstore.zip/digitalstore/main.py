"""
main.py
─────────────────────────────────────────────
Titik masuk (entry point) bot Telegram.

Tanggungjawab fail ini:
- Setup logging.
- Inisialisasi database.
- Cipta instance Bot & Dispatcher.
- Daftar semua router (handlers).
- Mulakan polling.

Untuk menjalankan bot:
    python main.py
"""

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.memory import MemoryStorage

from config import BOT_TOKEN, LOG_FILE, LOG_LEVEL
from database import init_db
from handlers import admin, user


def setup_logging() -> None:
    """
    Konfigurasi logging global.

    Log dihantar ke dua destinasi:
    - Konsol (stdout) — untuk pemantauan masa nyata.
    - Fail log (bot.log) — untuk rujukan/audit kemudian.
    """
    logging.basicConfig(
        level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(LOG_FILE, encoding="utf-8"),
        ],
    )


async def main() -> None:
    """Fungsi utama: setup dan mulakan bot."""
    setup_logging()
    logger = logging.getLogger(__name__)

    if BOT_TOKEN == "PASTE_BOT_TOKEN_DISINI" or not BOT_TOKEN:
        logger.error(
            "BOT_TOKEN belum ditetapkan. Sila edit fail config.py "
            "atau set environment variable BOT_TOKEN."
        )
        sys.exit(1)

    # Inisialisasi database (cipta jadual jika belum wujud)
    await init_db()

    # Cipta instance bot.
    # parse_mode=None kerana semua mesej menggunakan teks polos (plain text)
    # supaya simbol unicode dipaparkan tepat seperti yang direka, dan
    # elak isu escaping jika nama item mengandungi karakter istimewa.
    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=None),
    )

    # FSM storage di memori — sesuai untuk single-instance bot.
    dp = Dispatcher(storage=MemoryStorage())

    # Daftar router.
    # PENTING: router admin didaftarkan dahulu supaya arahan
    # admin (/add, /success, /send) tidak tertangkap oleh
    # handler umum di router user.
    dp.include_router(admin.router)
    dp.include_router(user.router)

    logger.info("Bot sedang dimulakan...")

    # Padam webhook (jika ada) supaya polling berjalan lancar,
    # dan abaikan update lama semasa bot offline.
    await bot.delete_webhook(drop_pending_updates=True)

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logging.getLogger(__name__).info("Bot dihentikan.")
