"""
config.py
─────────────────────────────────────────────
Konfigurasi utama bot. Semua nilai sensitif (token, admin id)
diletakkan di sini supaya mudah diubah tanpa menyentuh logik bot.

PENTING:
- Jangan kongsi BOT_TOKEN dengan sesiapa.
- ADMIN_ID mesti dalam bentuk integer (User ID Telegram admin).
"""

import os

# ─────────────────────────────────────────────
# TOKEN BOT
# Dapatkan token dari @BotFather di Telegram
# ─────────────────────────────────────────────
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "PASTE_BOT_TOKEN_DISINI")

# ─────────────────────────────────────────────
# ADMIN ID
# User ID Telegram admin (boleh lebih dari satu jika perlu)
# Untuk dapatkan User ID, hantar /start kepada @userinfobot
# ─────────────────────────────────────────────
ADMIN_IDS: list[int] = [
    7624612389,
]

# ─────────────────────────────────────────────
# QR CODE PEMBAYARAN
# -----------------------------------------------
# Pilihan 1 : QR_CODE_URL
#   Letakkan link terus ke imej QR (contoh: link dari imgur, telegra.ph,
#   atau mana-mana hosting imej). Bot akan guna link ini sebagai
#   "fallback" jika fail PNG tempatan tidak wujud / gagal dihantar.
#
# Pilihan 2 : QR_CODE_PATH
#   Letakkan path fail PNG QR Code yang disertakan dalam folder
#   "assets/". Bot akan cuba hantar fail ini dahulu.
#
# Susunan keutamaan: PNG fail tempatan -> jika gagal -> URL link
# -----------------------------------------------
QR_CODE_PATH: str = "assets/qrcode.png"
QR_CODE_URL: str = "https://example.com/path/ke/qrcode.png"

# ─────────────────────────────────────────────
# DATABASE
# ─────────────────────────────────────────────
DB_PATH: str = "store.db"

# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────
LOG_LEVEL: str = "INFO"
LOG_FILE: str = "bot.log"
