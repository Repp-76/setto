"""
handlers/user.py
─────────────────────────────────────────────
Handler untuk semua interaksi PEMBELI (user biasa):

- /start            : Memaparkan menu utama (senarai item)
- Klik butang item  : Mencipta order, notifikasi admin, hantar QR
- Hantar bukti      : Terima gambar/dokumen/fail sebagai bukti bayaran

Reka bentuk fokus kepada respon segera (tanpa delay) —
setiap mesej dihantar terus tanpa proses tambahan yang
tidak perlu.
"""

import logging

from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, FSInputFile, Message

import database as db
from config import ADMIN_IDS, QR_CODE_PATH, QR_CODE_URL
from utils import texts
from utils.keyboards import build_items_keyboard

logger = logging.getLogger(__name__)

router = Router(name="user")


# ─────────────────────────────────────────────
# /start
# ─────────────────────────────────────────────
@router.message(CommandStart())
async def cmd_start(message: Message) -> None:
    """
    Memaparkan mesej selamat datang serta senarai item
    yang tersedia (jika ada).
    """
    user = message.from_user
    full_name = user.full_name or "Pengguna"

    items = await db.get_all_items()

    text = texts.welcome_text(full_name, user.username, user.id)

    if items:
        keyboard = build_items_keyboard(items)
        await message.answer(text, reply_markup=keyboard)
    else:
        # Tiada item lagi — papar mesej tanpa button.
        await message.answer(text)

    logger.info("User %s (%s) menjalankan /start", user.id, user.username)


# ─────────────────────────────────────────────
# Klik butang item
# ─────────────────────────────────────────────
@router.callback_query(F.data.startswith("item:"))
async def on_item_selected(callback: CallbackQuery, bot: Bot) -> None:
    """
    Apabila pembeli menekan salah satu butang item:

    1. Jawab callback serta-merta (anti "loading" lama di sisi pembeli).
    2. Dapatkan maklumat item dari database.
    3. Cipta order baru (status: Pending).
    4. Hantar notifikasi "NEW ORDER" kepada semua admin.
    5. Hantar mesej pengesahan + QR Code kepada pembeli.
    """
    # Jawab callback dahulu supaya butang tidak "loading" — respon segera.
    await callback.answer()

    user = callback.from_user
    item_id = int(callback.data.split(":", 1)[1])

    item = await db.get_item_by_id(item_id)
    if not item:
        await callback.message.answer(texts.no_items_text())
        return

    # 1) Cipta order di database
    order_id = await db.create_order(
        user_id=user.id,
        username=user.username,
        item_name=item["name"],
        price=item["price"],
    )

    # 2) Beritahu pembeli tempahan telah diterima
    await callback.message.answer(texts.order_picked_text(item["name"]))

    # 3) Notifikasi semua admin tentang order baru
    admin_text = texts.admin_new_order_text(
        item_name=item["name"],
        full_name=user.full_name or "Pengguna",
        username=user.username,
        user_id=user.id,
        order_id=order_id,
    )
    for admin_id in ADMIN_IDS:
        try:
            await bot.send_message(admin_id, admin_text)
        except Exception:
            logger.exception("Gagal hantar notifikasi NEW ORDER ke admin %s", admin_id)

    # 4) Hantar QR Code pembayaran kepada pembeli
    await send_qr_code(bot, user.id, item["price"])

    # 5) Mesej meminta bukti pembayaran
    await bot.send_message(user.id, texts.payment_required_text(item["price"]))

    logger.info(
        "Order #%s dicipta: user=%s item=%s harga=%s",
        order_id, user.id, item["name"], item["price"],
    )


# ─────────────────────────────────────────────
# Hantar QR Code (PNG fail tempatan -> fallback link)
# ─────────────────────────────────────────────
async def send_qr_code(bot: Bot, chat_id: int, price: float) -> None:
    """
    Menghantar QR Code pembayaran kepada pembeli.

    Susunan keutamaan:
        1. Fail PNG tempatan (QR_CODE_PATH) — jika wujud & berjaya dihantar.
        2. Jika fail tidak wujud / gagal dihantar -> hantar melalui
           QR_CODE_URL sebagai link/imej fallback.
    """
    import os

    if os.path.isfile(QR_CODE_PATH):
        try:
            photo = FSInputFile(QR_CODE_PATH)
            await bot.send_photo(
                chat_id,
                photo=photo,
                caption=texts.qr_caption_text(price),
            )
            return
        except Exception:
            logger.exception(
                "Gagal hantar QR Code (fail tempatan), beralih ke link fallback."
            )

    # Fallback: hantar melalui URL
    try:
        await bot.send_photo(
            chat_id,
            photo=QR_CODE_URL,
            caption=texts.qr_link_fallback_text(price),
        )
    except Exception:
        # Jika URL bukan imej yang sah, hantar sebagai teks pautan.
        logger.exception("Gagal hantar QR Code melalui URL, hantar sebagai teks.")
        await bot.send_message(
            chat_id,
            f"{texts.qr_link_fallback_text(price)}\n\n{QR_CODE_URL}",
        )


# ─────────────────────────────────────────────
# Bukti pembayaran (gambar / dokumen / fail)
# ─────────────────────────────────────────────
@router.message(F.photo | F.document, ~F.from_user.id.in_(ADMIN_IDS))
async def on_payment_proof(message: Message, bot: Bot) -> None:
    """
    Menerima bukti pembayaran daripada pembeli (gambar/dokumen/fail).

    1. Cari order Pending terkini milik pembeli ini.
    2. Salin (forward/copy) bukti kepada admin bersama maklumat order.
    3. Tukar status order ke "Proof Sent".
    4. Maklumkan pembeli bukti telah diterima.
    """
    user = message.from_user

    order = await db.get_latest_pending_order(user.id)
    if not order:
        await message.answer(texts.no_pending_order_text())
        return

    # Maklumat untuk admin
    caption = texts.admin_payment_received_text(
        item_name=order["item_name"],
        full_name=user.full_name or "Pengguna",
        username=user.username,
        user_id=user.id,
        order_id=order["order_id"],
    )

    for admin_id in ADMIN_IDS:
        try:
            # Salin mesej (gambar/dokumen) terus kepada admin.
            await message.copy_to(chat_id=admin_id)
            await bot.send_message(admin_id, caption)
        except Exception:
            logger.exception("Gagal hantar bukti pembayaran ke admin %s", admin_id)

    # Kemas kini status order
    await db.update_order_status(order["order_id"], "Proof Sent")

    # Maklumkan pembeli
    await message.answer(texts.proof_received_buyer_text())

    logger.info(
        "Bukti pembayaran diterima: order=#%s user=%s",
        order["order_id"], user.id,
    )
