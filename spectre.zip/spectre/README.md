# SPECTRE OSINT Research Portal

Professional open-source intelligence navigation platform.
Cyberpunk black/red theme · Flask backend · SQLite · No external dependencies required.

---

## Project Structure

```
spectre/
├── run.py                      # Entry point
├── requirements.txt
├── app/
│   ├── __init__.py             # App factory, security headers
│   ├── database.py             # SQLite schema + seed data
│   ├── routes/
│   │   ├── main.py             # Public portal routes
│   │   ├── api.py              # JSON API (tree, search, export)
│   │   └── admin.py            # Admin CRUD panel
│   └── utils/
│       └── validators.py       # Input sanitisation
├── static/
│   ├── css/
│   │   ├── main.css            # Cyberpunk portal styles
│   │   └── admin.css           # Admin panel styles
│   └── js/
│       └── main.js             # Tree nav, search, UI logic
├── templates/
│   ├── base.html
│   ├── index.html              # Main portal page
│   └── admin/
│       ├── base_admin.html
│       ├── dashboard.html
│       ├── resources.html
│       ├── resource_form.html
│       ├── categories.html
│       ├── category_form.html
│       └── import.html
└── data/                       # Auto-created; holds spectre.db
    └── spectre.db
```

---

## Quick Start

### 1. Prerequisites
- Python 3.10+
- pip

### 2. Install dependencies

```bash
cd spectre
pip install -r requirements.txt
```

### 3. Run

```bash
python run.py
```

Open: **http://localhost:5000**
Admin: **http://localhost:5000/admin/**

The database is created automatically on first run with 150+ pre-loaded OSINT resources.

---

## API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/tree` | GET | Full nested category tree |
| `/api/categories/<id>` | GET | Category + its resources |
| `/api/search?q=<query>` | GET | Search categories & resources |
| `/api/export` | GET | Export all data as JSON |
| `/api/stats` | GET | Dashboard statistics |
| `/track/<id>` | POST | Log resource click (anonymous) |

---

## Admin Panel

Navigate to `/admin/` for:
- Add / Edit / Delete resources
- Add / Edit / Delete categories (unlimited nesting)
- Import JSON (file upload or paste)
- Export JSON (via `/api/export`)

---

## Security Notes

- All user input is sanitised via `bleach` before database writes
- Security headers applied to every response (CSP, X-Frame-Options, etc.)
- No authentication is included — add Flask-Login before exposing to a network
- Rate limiting can be re-enabled by uncommenting Flask-Limiter in `__init__.py`
- The platform is read-only by design — it only displays links, never fetches or scrapes

---

## Legal

SPECTRE is an educational research tool.
All listed resources are publicly accessible open-source intelligence platforms.
This platform does not perform automated data collection, scraping, exploitation,
or any unauthorised access. Users are responsible for compliance with applicable laws.
