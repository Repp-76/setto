"""
app/routes/api.py
-----------------
JSON API endpoints consumed by the frontend JavaScript.
All responses are application/json.

Endpoints:
  GET  /api/tree                  — full category tree with resource counts
  GET  /api/categories/<id>       — single category with its resources
  GET  /api/search?q=<query>      — search across categories and resources
  GET  /api/export                — export all data as JSON
"""

from flask import Blueprint, jsonify, request, current_app
from ..database import get_db
import json

api_bp = Blueprint("api", __name__)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _row_to_dict(row):
    """Convert a sqlite3.Row to a plain dict."""
    return dict(row)


def _build_tree(categories, parent_id=None):
    """
    Recursively build a nested category tree from a flat list.
    Each node: {id, name, slug, description, icon, sort_order, children, resource_count}
    """
    nodes = []
    for cat in categories:
        if cat["parent_id"] == parent_id:
            node = _row_to_dict(cat)
            node["children"] = _build_tree(categories, parent_id=cat["id"])
            nodes.append(node)
    nodes.sort(key=lambda n: n.get("sort_order", 0))
    return nodes


# ── Routes ─────────────────────────────────────────────────────────────────────

@api_bp.route("/tree")
def get_tree():
    """Return the full nested category tree with resource counts."""
    db = get_db()

    cats = db.execute("""
        SELECT c.id, c.name, c.slug, c.description, c.parent_id, c.icon, c.sort_order,
               COUNT(r.id) as resource_count
        FROM categories c
        LEFT JOIN resources r ON r.category_id = c.id AND r.status = 'active'
        GROUP BY c.id
        ORDER BY c.sort_order, c.name
    """).fetchall()

    cats_list = [_row_to_dict(c) for c in cats]
    tree = _build_tree(cats_list)
    return jsonify(tree)


@api_bp.route("/categories/<int:cat_id>")
def get_category(cat_id):
    """Return a single category and all its active resources."""
    db = get_db()

    cat = db.execute(
        "SELECT * FROM categories WHERE id=?", (cat_id,)
    ).fetchone()
    if not cat:
        return jsonify({"error": "Category not found"}), 404

    resources = db.execute("""
        SELECT id, name, description, url, tags, status, free, requires_account, added_at
        FROM resources
        WHERE category_id=? AND status='active'
        ORDER BY name
    """, (cat_id,)).fetchall()

    cat_dict = _row_to_dict(cat)

    # Parse tags JSON for each resource
    res_list = []
    for r in resources:
        rd = _row_to_dict(r)
        try:
            rd["tags"] = json.loads(rd.get("tags") or "[]")
        except (json.JSONDecodeError, TypeError):
            rd["tags"] = []
        res_list.append(rd)

    cat_dict["resources"] = res_list
    return jsonify(cat_dict)


@api_bp.route("/search")
def search():
    """
    Full-text search across category names, resource names, descriptions, and tags.
    Query parameter: q (minimum 2 characters).
    """
    q = request.args.get("q", "").strip()
    if len(q) < 2:
        return jsonify({"categories": [], "resources": []})

    db = get_db()
    like = f"%{q}%"

    # Search categories
    cats = db.execute("""
        SELECT id, name, slug, description, icon
        FROM categories
        WHERE name LIKE ? OR description LIKE ?
        ORDER BY name
        LIMIT 20
    """, (like, like)).fetchall()

    # Search resources (include tags text match)
    resources = db.execute("""
        SELECT r.id, r.name, r.description, r.url, r.tags, r.status, r.free,
               c.name as category_name, c.id as category_id, c.slug as category_slug
        FROM resources r
        JOIN categories c ON c.id = r.category_id
        WHERE r.status = 'active'
          AND (r.name LIKE ? OR r.description LIKE ? OR r.tags LIKE ?)
        ORDER BY r.name
        LIMIT 50
    """, (like, like, like)).fetchall()

    cats_list = [_row_to_dict(c) for c in cats]
    res_list = []
    for r in resources:
        rd = _row_to_dict(r)
        try:
            rd["tags"] = json.loads(rd.get("tags") or "[]")
        except (json.JSONDecodeError, TypeError):
            rd["tags"] = []
        res_list.append(rd)

    return jsonify({"categories": cats_list, "resources": res_list})


@api_bp.route("/export")
def export_data():
    """Export all categories and resources as a single JSON document."""
    db = get_db()

    cats = db.execute("SELECT * FROM categories ORDER BY sort_order, name").fetchall()
    resources = db.execute("SELECT * FROM resources ORDER BY category_id, name").fetchall()

    cats_list = [_row_to_dict(c) for c in cats]
    res_list  = []
    for r in resources:
        rd = _row_to_dict(r)
        try:
            rd["tags"] = json.loads(rd.get("tags") or "[]")
        except Exception:
            rd["tags"] = []
        res_list.append(rd)

    payload = {
        "version": "1.0",
        "categories": cats_list,
        "resources":  res_list
    }
    return jsonify(payload)


@api_bp.route("/stats")
def stats():
    """Return dashboard statistics."""
    db = get_db()

    total_res  = db.execute("SELECT COUNT(*) FROM resources WHERE status='active'").fetchone()[0]
    total_cats = db.execute("SELECT COUNT(*) FROM categories").fetchone()[0]
    free_res   = db.execute("SELECT COUNT(*) FROM resources WHERE free=1 AND status='active'").fetchone()[0]

    top_cats = db.execute("""
        SELECT c.name, c.slug, c.icon, COUNT(ul.id) as hits
        FROM categories c
        LEFT JOIN resources r ON r.category_id = c.id
        LEFT JOIN usage_log ul ON ul.resource_id = r.id
        GROUP BY c.id ORDER BY hits DESC LIMIT 5
    """).fetchall()

    return jsonify({
        "total_resources":  total_res,
        "total_categories": total_cats,
        "free_resources":   free_res,
        "top_categories":   [_row_to_dict(c) for c in top_cats]
    })
