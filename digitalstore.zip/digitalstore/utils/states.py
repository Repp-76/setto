"""
utils/states.py
─────────────────────────────────────────────
Definisi Finite State Machine (FSM) states yang digunakan
oleh bot untuk mengendalikan perbualan bersiri
(multi-step conversation) dengan admin.

State digunakan untuk:
- Menunggu admin memasukkan harga selepas /add
"""

from aiogram.fsm.state import State, StatesGroup


class AddItemStates(StatesGroup):
    """State machine untuk proses /add {nama item}."""

    waiting_for_price = State()
